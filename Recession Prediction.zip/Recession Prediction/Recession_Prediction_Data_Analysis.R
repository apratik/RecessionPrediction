## Clearing Objects
rm(list = ls())

# Importing Library

suppressPackageStartupMessages({
  if (!require("stargazer"))
    install.packages("stargazer")
  library(stargazer)
  if (!require("gbm"))
    install.packages("gbm")
  library(gbm)
  if (!require("Information"))
    install.packages("Information")
  library(Information)
  if (!require("factoextra"))
    install.packages("factoextra")
  library(factoextra)
  if (!require("ggfortify"))
    install.packages("ggfortify")
  library(ggfortify)
  if (!require("r2d3"))
    install.packages("r2d3")
  library(r2d3)
  if (!require("devtools"))
    install.packages("devtools")
  library(devtools)
  if (!require("DataExplorer"))
    install.packages("DataExplorer")
  library(DataExplorer)
  if (!require("caret"))
    install.packages("caret")
  library(caret)
  if (!require("rpart"))
    install.packages("rpart")
  library(rpart)
  if (!require("rpart.plot"))
    install.packages("rpart.plot")
  library(rpart.plot)
  if (!require("rattle"))
    install.packages("rattle")
  library(rattle)
  if (!require("RColorBrewer"))
    install.packages("RColorBrewer")
  library(RColorBrewer)
  if (!require("party"))
    install.packages("party")
  library(party)
  if (!require("partykit"))
    install.packages("partykit")
  library(partykit)
  if (!require("dplyr"))
    install.packages("dplyr")
  library(dplyr)
  if (!require("zoo"))
    install.packages("zoo")
  library(zoo)
  if (!require("scales"))
    install.packages("scales")
  library(scales)
  if (!require("colorspace"))
    install.packages("colorspace")
  library(colorspace)
  if (!require("varImp"))
    install.packages("varImp")
  library(varImp)
  if (!require("earth"))
    install.packages("earth")
  library(earth)
  if (!require("MASS"))
    install.packages("MASS")
  library(MASS)
  if (!require("car"))
    install.packages("car")
  library(car)
  if (!require("Quandl"))
    install.packages("Quandl")
  library(Quandl)
  if (!require("forecast"))
    install.packages("forecast")
  library(forecast)
  if (!require("e1071"))
    install.packages("e1071")
  library(e1071)
  if (!require("quantmod"))
    install.packages("quantmod")
  library(quantmod)
  if (!require("xts"))
    install.packages("xts")
  library(xts)
  if (!require("TTR"))
    install.packages("TTR")
  library(TTR)
  if (!require("ggplot2"))
    install.packages("ggplot2")
  library(ggplot2)
  if (!require("cowplot"))
    install.packages("cowplot")
  library(cowplot)
  if (!require("RColorBrewer"))
    install.packages("RColorBrewer")
  library(RColorBrewer)
  if (!require("tseries"))
    install.packages("tseries")
  library(tseries)
  if (!require("lubridate"))
    install.packages("lubridate")
  library(lubridate)
  if (!require("ClustOfVar"))
    install.packages("ClustOfVar")
  library(ClustOfVar)
  if (!require("reshape2"))
    install.packages("reshape2")
  library(reshape2)
  if (!require("plyr"))
    install.packages("plyr")
  library(plyr)
  if (!require("Boruta"))
    install.packages("Boruta")
  library(Boruta)
  if (!require("inspectdf"))
    install.packages("inspectdf")
  library(inspectdf)
  if (!require("tidyverse"))
    install.packages("tidyverse")
  library(tidyverse)
  if (!require("readr"))
    install.packages("readr")
  library(readr)
  if (!require("Rdimtools"))
    install.packages("Rdimtools")
  library(Rdimtools)
  if (!require("corrr"))
    install.packages("corrr")
  library(corrr)
  if (!require("rAverage"))
    install.packages("rAverage")
  library(rAverage)
  if (!require("arm"))
    install.packages("arm")
  library(arm)
  if (!require("outliers"))
    install.packages("outliers")
  library(outliers)
})

library(xgboost)
library(readr)
library(stringr)


# Yearly/Quarterly To Monthly Conversion

convert_to_monthly_data <- function(input_df) {
  zd <- read.zoo(input_df, index.column = 1)
  tt <- as.yearmon(seq(start(zd), end(zd), "month"))
  zm <- na.spline(zd, as.yearmon, xout = tt)
  output_df <- fortify.zoo(zm)
}


# GDP (2007 index as 100)
# U.S. Bureau of Economic Analysis, Gross Domestic Product [GDP], retrieved from FRED, Federal Reserve Bank of St. Louis; https://fred.stlouisfed.org/series/GDP, November 30, 2019.

gdp_quarterly <-
  read.csv(
    file = "gdp-percent-change-quarterly.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

gdp <- convert_to_monthly_data(gdp_quarterly)

remove(gdp_quarterly)

names(gdp)[1] <- "Time"
names(gdp)[2] <- "gdp_val"

summary(gdp)

# Income and Disposition
# OECD (2019), Household disposable income (indicator). doi: 10.1787/dd50eddd-en (Accessed on 30 November 2019)

income_disposition_monthly <-
  read.csv(
    file = "income_disposition_monthly.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

income_disposition <-
  convert_to_monthly_data(income_disposition_monthly)

names(income_disposition)[1] <- "Time"
names(income_disposition)[2] <- "income_disposition_val"

summary(income_disposition)

remove(income_disposition_monthly)

# nonfinancial_business_quarterly (2007 index as 100)
# U.S. Bureau of Economic Analysis, Gross value added of nonfinancial corporate business [A455RC1Q027SBEA], retrieved from FRED, Federal Reserve Bank of St. Louis; https://fred.stlouisfed.org/series/A455RC1Q027SBEA, November 30, 2019.

nonfinancial_business_quarterly <-
  read.csv(
    file = "nonfinancial_business_quarterly.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

nonfinancial_business <-
  convert_to_monthly_data(nonfinancial_business_quarterly)

names(nonfinancial_business)[1] <- "Time"

names(nonfinancial_business)[2] <- "nonfinancial_business_val"

# View(nonfinancial_business)

remove(nonfinancial_business_quarterly)

# Crude Oil
# Federal Reserve Bank of St. Louis, Spot Crude Oil Price: West Texas Intermediate (WTI) [WTISPLC], retrieved from FRED, Federal Reserve Bank of St. Louis; https://fred.stlouisfed.org/series/WTISPLC, November 30, 2019.

crude_oil_monthly <-
  read.csv(
    file = "crude_oil_monthly.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

crude_oil <- convert_to_monthly_data(crude_oil_monthly)

names(crude_oil)[1] <- "Time"

names(crude_oil)[2] <- "crude_oil_val"


# View(crude_oil)

remove(crude_oil_monthly)

# Gold
# ICE Benchmark Administration Limited (IBA), Gold Fixing Price 10:30 A.M. (London time) in London Bullion Market, based in U.S. Dollars [GOLDAMGBD228NLBM], retrieved from FRED, Federal Reserve Bank of St. Louis; https://fred.stlouisfed.org/series/GOLDAMGBD228NLBM, November 30, 2019.

gold_daily <-
  read.csv(
    file = "gold_daily_formatted.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE,
    na.strings = c("NA", "NaN", " ", ".", "")
  )

gold_monthly <- convert_to_monthly_data(gold_daily)

names(gold_monthly)[1] <- "Time"

names(gold_monthly)[2] <- "gold_monthly_val"

# # View(gold_monthly)

remove(gold_daily)

# Personal Saving Rate
# U.S. Bureau of Economic Analysis, Personal Saving Rate [PSAVERT], retrieved from FRED, Federal Reserve Bank of St. Louis; https://fred.stlouisfed.org/series/PSAVERT, November 30, 2019.

saving_rate <-
  read.csv(
    file = "personal_saving_rate.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

saving_rate <- convert_to_monthly_data(saving_rate)

names(saving_rate)[1] <- "Time"

names(saving_rate)[2] <- "saving_rate_val"

# # View(saving_rate)

#remove(saving_rate_annual)

# building_permit
# U.S. Census Bureau and U.S. Department of Housing and Urban Development, New Private Housing Units Authorized by Building Permits [PERMIT], retrieved from FRED, Federal Reserve Bank of St. Louis; https://fred.stlouisfed.org/series/PERMIT, November 30, 2019.

building_permit_monthly <-
  read.csv(
    file = "building_permit_monthly.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

building_permit <- convert_to_monthly_data(building_permit_monthly)

names(building_permit)[1] <- "Time"

names(building_permit)[2] <- "building_permit_val"


# # View(building_permit)

remove(building_permit_monthly)

# business_confidence

business_confidence_monthly <-
  read.csv(
    file = "business_confidence_monthly.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

business_confidence <-
  convert_to_monthly_data(business_confidence_monthly)

names(business_confidence)[1] <- "Time"

names(business_confidence)[2] <- "business_confidence_val"

# # View(business_confidence)

remove(business_confidence_monthly)


# consumer_confidence

consumer_confidence_monthly <-
  read.csv(
    file = "consumer_confidence_monthly.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

consumer_confidence <-
  convert_to_monthly_data(consumer_confidence_monthly)

names(consumer_confidence)[1] <- "Time"

names(consumer_confidence)[2] <- "consumer_confidence_val"

# # View(consumer_confidence)

remove(consumer_confidence_monthly)

# Inflation - CPI

cpi_monthly <-
  read.csv(
    file = "cpi_monthly.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

cpi <- convert_to_monthly_data(cpi_monthly)

names(cpi)[1] <- "Time"

names(cpi)[2] <- "cpi_val"

# # View(cpi)

remove(cpi_monthly)

# housing_price

housing_price_quarterly <-
  read.csv(
    file = "housing_price_quarterly.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

housing_price <- convert_to_monthly_data(housing_price_quarterly)

names(housing_price)[1] <- "Time"

names(housing_price)[2] <- "housing_price_val"

# # View(housing_price)

remove(housing_price_quarterly)

# industrial_production

industrial_production_monthly <-
  read.csv(
    file = "industrial_production_monthly.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

industrial_production <-
  convert_to_monthly_data(industrial_production_monthly)

names(industrial_production)[1] <- "Time"

names(industrial_production)[2] <- "industrial_production_val"


# # View(industrial_production)

remove(industrial_production_monthly)

# net_trade

net_trade_monthly <-
  read.csv(
    file = "net_trade_monthly.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

net_trade <- convert_to_monthly_data(net_trade_monthly)

names(net_trade)[1] <- "Time"

names(net_trade)[2] <- "net_trade_val"

# # View(net_trade)

remove(net_trade_monthly)

# production_sales

production_sales_monthly <-
  read.csv(
    file = "production_sales_monthly.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

production_sales <-
  convert_to_monthly_data(production_sales_monthly)

names(production_sales)[1] <- "Time"

names(production_sales)[2] <- "production_val"

names(production_sales)[3] <- "sales_val"


# # View(production_sales)

remove(production_sales_monthly)

# military expense

military_expense <-
  read.csv(
    file = "military_expense.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )


names(military_expense)[1] <- "Time"

names(military_expense)[2] <- "military_expense_val"

military_expense[] <-
  lapply(military_expense, function(x)
    if (is.character(x))
      as.yearmon(x)
    else
      x)

## View(military_expense)


# us_party_in_power

us_party_in_power <-
  read.csv(
    file = "us_party_in_power.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

# View(us_party_in_power)

names(us_party_in_power)[1] <- "Time"

names(us_party_in_power)[2] <- "democrat_rule"

names(us_party_in_power)[3] <- "republican_rule"

## View(us_party_in_power)

us_party_in_power[] <-
  lapply(us_party_in_power, function(x)
    if (is.character(x))
      as.yearmon(x)
    else
      x)


# unemployment rate

unemployment_rate <-
  read.csv(
    file = "unemployment_rate.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

names(unemployment_rate)[1] <- "Time"

names(unemployment_rate)[2] <- "unemployment_rate"

unemployment_rate[] <-
  lapply(unemployment_rate, function(x)
    if (is.character(x))
      as.yearmon(x)
    else
      x)

# View(unemployment_rate)

# us fdi inflow

us_inflow_annual <-
  read.csv(
    file = "us_inflow.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

us_inflow <- convert_to_monthly_data(us_inflow_annual)

names(us_inflow)[1] <- "Time"

names(us_inflow)[2] <- "us_inflow_val"

# View(us_inflow)

remove(us_inflow_annual)

# us fdi outflow

us_outflow_annual <-
  read.csv(
    file = "us_outflow.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

us_outflow <- convert_to_monthly_data(us_outflow_annual)

names(us_outflow)[1] <- "Time"

names(us_outflow)[2] <- "us_outflow_val"

# View(us_outflow)

remove(us_outflow_annual)

# additional_index

additional_index <-
  read.csv(
    file = "additional_index.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

names(additional_index)[1] <- "Time"

additional_index[] <-
  lapply(additional_index, function(x)
    if (is.character(x))
      as.yearmon(x)
    else
      x)

# View(additional_index)

# GDP of major countries

major_countries_gdp_annual <-
  read.csv(
    file = "major_countries_gdp.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

major_countries_gdp <-
  convert_to_monthly_data(major_countries_gdp_annual)

names(major_countries_gdp)[1] <- "Time"

#View(major_countries_gdp)

remove(major_countries_gdp_annual)

# share_price

share_price_monthly <-
  read.csv(
    file = "share_price_monthly.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

share_price <- convert_to_monthly_data(share_price_monthly)

names(share_price)[1] <- "Time"

names(share_price)[2] <- "share_price_val"

# # View(share_price)

remove(share_price_monthly)

# household debt

household_debt_quarter <-
  read.csv(
    file = "household_debt.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

household_debt <- convert_to_monthly_data(household_debt_quarter)

names(household_debt)[1] <- "Time"

names(household_debt)[2] <- "household_debt_val"

# View(household_debt)

remove(household_debt_quarter)

# recession_indicator

recession_indicator <-
  read.csv(
    file = "recession_indicator_monthly.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

names(recession_indicator)[1] <- "Time"

names(recession_indicator)[2] <- "recession_indicator_val"

recession_indicator[] <-
  lapply(recession_indicator, function(x)
    if (is.character(x))
      as.yearmon(x)
    else
      x)


# Merging dataframes

masterDfList <-
  list(
    building_permit[1:592,],
    business_confidence[1:592,],
    consumer_confidence[1:592,],
    cpi[1:592,],
    crude_oil[1:592,],
    gdp[1:592,],
    gold_monthly[1:592,],
    housing_price[1:592,],
    income_disposition[1:592,],
    industrial_production[1:592,],
    net_trade[1:592,],
    nonfinancial_business[1:592,],
    production_sales[1:592,],
    saving_rate[1:592,],
    share_price[1:592,],
    military_expense[1:592,],
    us_party_in_power[1:592,],
    unemployment_rate[1:592,],
    us_inflow[1:592,],
    us_outflow[1:592,],
    additional_index[1:592,],
    major_countries_gdp[1:592,],
    household_debt[1:592,],
    recession_indicator[1:592,]
  )

master_data <-
  Reduce(function(x, y)
    merge(x, y, all = TRUE), masterDfList)


#View(master_data)
## Check Master data set for NA's - It is observed that there are NA's in data set
sapply(master_data, function(x)
  sum(is.na(x)))

# # View(master_data)

master_data <-
  master_data[!apply(is.na(master_data) |
                       master_data == "", 1, all),]

# View(master_data)

master_data$Time <- as.Date(as.yearmon(master_data$Time))

# DataExplorer::create_report(master_data)  # GenerateReport(master_data)

#View(psych::describe(master_data))

# View(sapply(master_data, class))

######### Descriptive statistics Using Stargazer package #######################
# stargazer(master_data, type = "html", title="Descriptive statistics", digits = 2, out="DescriptiveStat.html")

##############

## Plot Outliers

#plot_boxplot(master_data[2:53], by = "recession_indicator_val", geom_boxplot_args = list("outlier.color" = "red"))

#capOutlier <- function(x){
#  quantiles <- quantile( x, c(.05, .95 ) )
#  print(quantiles)
#  x[ x < quantiles[1] ] <- quantiles[1]
#  x[ x > quantiles[2] ] <- quantiles[2]
#  return(x)
#}

capOutlier <- function(x) {
  for (i in which(sapply(x, is.numeric))) {
    quantiles <- quantile(x[, i], c(.05, .95), na.rm = TRUE)
    x[, i] = ifelse(x[, i] < quantiles[1] , quantiles[1], x[, i])
    x[, i] = ifelse(x[, i] > quantiles[2] , quantiles[2], x[, i])
  }
  x
}

# dim(master_data)

plot_boxplot(master_data,
             by = "recession_indicator_val",
             geom_boxplot_args = list("outlier.color" = "red"))


master_data = capOutlier(master_data)

# Recession Period Data Timelines

recessions.df = read.table(
  textConnection(
    "Peak, Trough
1969-12-01, 1970-11-01
1973-11-01, 1975-03-01
1980-01-01, 1980-07-01
1981-07-01, 1982-11-01
1990-07-01, 1991-03-01
2001-03-01, 2001-11-01
2007-12-01, 2009-06-01"
  ),
  sep = ',',
  colClasses = c('Date', 'Date'),
  header = TRUE
)

# Predictor's Variation during recession period
ggplot(master_data) + geom_line(aes(x = Time, y = building_permit_val)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = business_confidence_val)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = consumer_confidence_val)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = cpi_val)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = crude_oil_val)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = gdp_val)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = gold_monthly_val)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = housing_price_val)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = income_disposition_val)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = industrial_production_val)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = net_trade_val)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = nonfinancial_business_val)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = production_val)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = sales_val)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = saving_rate_val)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = share_price_val)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = military_expense_val)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = democrat_rule)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = republican_rule)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = unemployment_rate)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = us_inflow_val)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = us_outflow_val)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = help_wanted_idx)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = avg_employment_duration_week)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = employment_insurance_claim)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = eff_fed_fund_rate)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = xchg_switz_us_curr)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = xchg_jpn_us_curr)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = xchg_uk_us_curr)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = xchg_cad_us_curr)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = germany_recession)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = italy_recession)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = france_recession)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = canada_recession)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = japan_recession)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = uk_recession)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = s_and_p_return_rate)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = long_term_yield_rate_us)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = long_term_yield_rate_germany)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = long_term_yield_rate_canada)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = long_term_yield_rate_france)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = long_term_yield_rate_uk)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = japan_gdp)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = canada_gdp)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = france_gdp)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = germany_gdp)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = italy_gdp)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = uk_gdp)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = china_gdp)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = india_gdp)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))
ggplot(master_data) + geom_line(aes(x = Time, y = household_debt_val)) + theme_bw() +
  geom_rect(
    data = recessions.df,
    aes(
      xmin = Peak,
      xmax = Trough,
      ymin = -Inf,
      ymax = +Inf
    ),
    fill = 'red',
    alpha = 0.2
  ) + scale_x_date(date_breaks = '2 years', labels = date_format("%b-%y"))

# Correlation

rs_pearson <- corrr::correlate(master_data[-1], method = "pearson")

#View(rs_pearson)

rs_pearson %>% rplot()

correlation_val_df <- rs_pearson %>%
  focus(recession_indicator_val)

rs_pearson %>%
  focus(recession_indicator_val) %>%
  mutate(rowname = reorder(rowname, recession_indicator_val)) %>%
  ggplot(aes(rowname, recession_indicator_val)) +
  geom_col() + coord_flip()

# spearman correlation

rs_spearman <-
  corrr::correlate(master_data[-1], method = "spearman", diagonal = 1)

rs_spearman %>% rplot()

sp_correlation_val_df <- rs_spearman %>%
  focus(recession_indicator_val)

#View(sp_correlation_val_df)

rs_spearman %>%
  focus(recession_indicator_val) %>%
  mutate(rowname = reorder(rowname, recession_indicator_val)) %>%
  ggplot(aes(rowname, recession_indicator_val)) +
  geom_col() + coord_flip()

# Using Information Value

IV <-
  create_infotables(master_data[,-1], y = "recession_indicator_val", ncore = 2)

# IV table for understanding
IV$Tables

# create DF with IV values
IvDF <- IV$Summary

#View(IvDF)

IvDF$feedback <- NULL

nrow(IvDF)

# View(IvDF)

# - Plot IV

for (i in 1:nrow(IvDF)) {
  if (IvDF$IV[i] < 0.02) {
    IvDF$feedback[i] = "Useless"
  } else if (IvDF$IV[i] >= 0.02 & IvDF$IV[i] < 0.1) {
    IvDF$feedback[i] = "Weak"
  } else if (IvDF$IV[i] >= 0.1 & IvDF$IV[i] < 0.3) {
    IvDF$feedback[i] = "Medium"
  } else if (IvDF$IV[i] >= 0.3 & IvDF$IV[i] < 0.5) {
    IvDF$feedback[i] = "Strong"
  }
  else if (IvDF$IV[i] >= 0.5) {
    IvDF$feedback[i] = "Very Strong"
  }
}

ggplot(IvDF, aes(x = Variable, y = IV)) +
  geom_bar(
    width = .35,
    stat = "identity",
    color = "darkblue",
    fill = "white"
  ) +
  ggtitle("Information Value") +
  theme_bw() +
  theme(plot.title = element_text(size = 10)) +
  theme(axis.text.x = element_text(angle = 90))


# Boruta Importance

# Boruta can be your algorithm of choice to deal with such data sets.
# Particularly when one is interested in understanding the mechanisms
# related to the variable of interest, rather than just building a black
# box predictive model with good prediction accuracy.

# How does it work?
# Below is the step wise working of boruta algorithm:

# Firstly, it adds randomness to the given data set by creating shuffled copies
# of all features (which are called shadow features).
# Then, it trains a random forest classifier on the extended data set and applies
# a feature importance measure (the default is Mean Decrease Accuracy) to evaluate
# the importance of each feature where higher means more important.
# At every iteration, it checks whether a real feature has a higher importance than
# the best of its shadow features (i.e. whether the feature has a higher Z score
# than the maximum Z score of its shadow features) and constantly removes features
# which are deemed highly unimportant.
# Finally, the algorithm stops either when all features gets confirmed or rejected
# or it reaches a specified limit of random forest runs.

dim(master_data)

set.seed(123)

boruta.train <-
  Boruta(recession_indicator_val ~ .,
         data = master_data,
         doTrace = 2)

print(boruta.train)

plot(boruta.train, xlab = "", xaxt = "n")

lz <- lapply(1:ncol(boruta.train$ImpHistory), function(i)
  boruta.train$ImpHistory[is.finite(boruta.train$ImpHistory[, i]), i])


names(lz) <- colnames(boruta.train$ImpHistory)

Labels <- sort(sapply(lz, median))

axis(
  side = 1,
  las = 2,
  labels = names(Labels),
  at = 1:ncol(boruta.train$ImpHistory),
  cex.axis = 0.7
)

final.boruta <- TentativeRoughFix(boruta.train)

print(final.boruta)

getSelectedAttributes(final.boruta, withTentative = F)

boruta.df <- attStats(final.boruta)

# class(boruta.df)

# View(boruta.df)

# Create TS object of data

# Transform to `ts` class

building_permit_ts <-
  ts(
    master_data$building_permit_val,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
business_confidence_ts <-
  ts(
    master_data$business_confidence_val,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
consumer_confidence_ts <-
  ts(
    master_data$consumer_confidence_val,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
cpi_ts <-
  ts(
    master_data$cpi_val,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
crude_oil_ts <-
  ts(
    master_data$crude_oil_val,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
gdp_ts <-
  ts(
    master_data$gdp_val,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
gold_monthly_ts <-
  ts(
    master_data$gold_monthly_val,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
housing_price_ts <-
  ts(
    master_data$housing_price_val,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
income_disposition_ts <-
  ts(
    master_data$income_disposition_val,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
industrial_production_ts <-
  ts(
    master_data$industrial_production_val,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
net_trade_ts <-
  ts(
    master_data$net_trade_val,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
nonfinancial_business_ts <-
  ts(
    master_data$nonfinancial_business_val,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
production_ts <-
  ts(
    master_data$production_val,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
sales_ts <-
  ts(
    master_data$sales_val,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
saving_rate_ts <-
  ts(
    master_data$saving_rate_val,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
share_price_ts <-
  ts(
    master_data$share_price_val,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
military_expense_ts <-
  ts(
    master_data$military_expense_val,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
democrat_rule_ts <-
  ts(
    master_data$democrat_rule,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
republican_rule_ts <-
  ts(
    master_data$republican_rule,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
unemployment_rate_ts <-
  ts(
    master_data$unemployment_rate,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
us_inflow_ts <-
  ts(
    master_data$us_inflow_val,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
us_outflow_ts <-
  ts(
    master_data$us_outflow_val,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
help_wanted_idx_ts <-
  ts(
    master_data$help_wanted_idx,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
avg_employment_duration_week_ts <-
  ts(
    master_data$avg_employment_duration_week,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
employment_insurance_claim_ts <-
  ts(
    master_data$employment_insurance_claim,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
eff_fed_fund_rate_ts <-
  ts(
    master_data$eff_fed_fund_rate,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
xchg_switz_us_curr_ts <-
  ts(
    master_data$xchg_switz_us_curr,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
xchg_jpn_us_curr_ts <-
  ts(
    master_data$xchg_jpn_us_curr,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
xchg_uk_us_curr_ts <-
  ts(
    master_data$xchg_uk_us_curr,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
xchg_cad_us_curr_ts <-
  ts(
    master_data$xchg_cad_us_curr,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
germany_recession_ts <-
  ts(
    master_data$germany_recession,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
italy_recession_ts <-
  ts(
    master_data$italy_recession,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
france_recession_ts <-
  ts(
    master_data$france_recession,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
canada_recession_ts <-
  ts(
    master_data$canada_recession,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
japan_recession_ts <-
  ts(
    master_data$japan_recession,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
uk_recession_ts <-
  ts(
    master_data$uk_recession,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
s_and_p_return_rate_ts <-
  ts(
    master_data$s_and_p_return_rate,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
long_term_yield_rate_us_ts <-
  ts(
    master_data$long_term_yield_rate_us,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
long_term_yield_rate_germany_ts <-
  ts(
    master_data$long_term_yield_rate_germany,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
long_term_yield_rate_canada_ts <-
  ts(
    master_data$long_term_yield_rate_canada,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
long_term_yield_rate_france_ts <-
  ts(
    master_data$long_term_yield_rate_france,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
long_term_yield_rate_uk_ts <-
  ts(
    master_data$long_term_yield_rate_uk,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
japan_gdp_ts <-
  ts(
    master_data$japan_gdp,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
canada_gdp_ts <-
  ts(
    master_data$canada_gdp,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
france_gdp_ts <-
  ts(
    master_data$france_gdp,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
germany_gdp_ts <-
  ts(
    master_data$germany_gdp,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
italy_gdp_ts <-
  ts(
    master_data$italy_gdp,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
uk_gdp_ts <-
  ts(
    master_data$uk_gdp,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
china_gdp_ts <-
  ts(
    master_data$china_gdp,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
india_gdp_ts <-
  ts(
    master_data$india_gdp,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
household_debt_ts <-
  ts(
    master_data$household_debt_val,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )
recession_indicator_ts <-
  ts(
    master_data$recession_indicator_val,
    start = c(1970, 1),
    end = c(2019, 4),
    freq = 12
  )

## Custom function of decomposition

my_plot.decomposed.ts = function(x, title = x, ...) {
  xx <- x$x
  if (is.null(xx))
    xx <- with(x,
               if (type == "additive")
                 random + trend + seasonal + cyclic
               else
                 random * trend * seasonal * cyclic)
  plot(
    cbind(
      observed = xx,
      trend = x$trend,
      seasonal = x$seasonal,
      random = x$random,
      cyclic = x$cyclic
    ),
    main = title,
    ...
  )
}

# Decomposition

my_plot.decomposed.ts(decompose(building_permit_ts), "building_permit")
my_plot.decomposed.ts(decompose(business_confidence_ts), "business_confidence")
my_plot.decomposed.ts(decompose(consumer_confidence_ts), "consumer_confidence")
my_plot.decomposed.ts(decompose(cpi_ts), "cpi")
my_plot.decomposed.ts(decompose(crude_oil_ts), "crude_oil")
my_plot.decomposed.ts(decompose(gdp_ts), "gdp")
my_plot.decomposed.ts(decompose(gold_monthly_ts), "gold_monthly")
my_plot.decomposed.ts(decompose(housing_price_ts), "housing_price")
my_plot.decomposed.ts(decompose(income_disposition_ts), "income_disposition")
my_plot.decomposed.ts(decompose(industrial_production_ts), "industrial_production")
my_plot.decomposed.ts(decompose(net_trade_ts), "net_trade")
my_plot.decomposed.ts(decompose(nonfinancial_business_ts), "nonfinancial_business")
my_plot.decomposed.ts(decompose(production_ts), "production")
my_plot.decomposed.ts(decompose(sales_ts), "sales")
my_plot.decomposed.ts(decompose(saving_rate_ts), "saving_rate")
my_plot.decomposed.ts(decompose(share_price_ts), "share_price")
my_plot.decomposed.ts(decompose(military_expense_ts), "military_expense")
my_plot.decomposed.ts(decompose(democrat_rule_ts), "democrat_rule")
my_plot.decomposed.ts(decompose(republican_rule_ts), "republican_rule")
my_plot.decomposed.ts(decompose(unemployment_rate_ts), "unemployment_rate")
my_plot.decomposed.ts(decompose(us_inflow_ts), "us_inflow")
my_plot.decomposed.ts(decompose(us_outflow_ts), "us_outflow")
my_plot.decomposed.ts(decompose(help_wanted_idx_ts), "help_wanted_idx")
my_plot.decomposed.ts(decompose(avg_employment_duration_week_ts), "avg_employment_duration_week")
my_plot.decomposed.ts(decompose(employment_insurance_claim_ts), "employment_insurance_claim")
my_plot.decomposed.ts(decompose(eff_fed_fund_rate_ts), "eff_fed_fund_rate")
my_plot.decomposed.ts(decompose(xchg_switz_us_curr_ts), "xchg_switz_us_curr")
my_plot.decomposed.ts(decompose(xchg_jpn_us_curr_ts), "xchg_jpn_us_curr")
my_plot.decomposed.ts(decompose(xchg_uk_us_curr_ts), "xchg_uk_us_curr")
my_plot.decomposed.ts(decompose(xchg_cad_us_curr_ts), "xchg_cad_us_curr")
my_plot.decomposed.ts(decompose(germany_recession_ts), "germany_recession")
my_plot.decomposed.ts(decompose(italy_recession_ts), "italy_recession")
my_plot.decomposed.ts(decompose(france_recession_ts), "france_recession")
my_plot.decomposed.ts(decompose(canada_recession_ts), "canada_recession")
my_plot.decomposed.ts(decompose(japan_recession_ts), "japan_recession")
my_plot.decomposed.ts(decompose(uk_recession_ts), "uk_recession")
my_plot.decomposed.ts(decompose(s_and_p_return_rate_ts), "s_and_p_return_rate")
my_plot.decomposed.ts(decompose(long_term_yield_rate_us_ts), "long_term_yield_rate_us")
my_plot.decomposed.ts(decompose(long_term_yield_rate_germany_ts), "long_term_yield_rate_germany")
my_plot.decomposed.ts(decompose(long_term_yield_rate_canada_ts), "long_term_yield_rate_canada")
my_plot.decomposed.ts(decompose(long_term_yield_rate_france_ts), "long_term_yield_rate_france")
my_plot.decomposed.ts(decompose(long_term_yield_rate_uk_ts), "long_term_yield_rate_uk")
my_plot.decomposed.ts(decompose(japan_gdp_ts), "japan_gdp")
my_plot.decomposed.ts(decompose(canada_gdp_ts), "canada_gdp")
my_plot.decomposed.ts(decompose(france_gdp_ts), "france_gdp")
my_plot.decomposed.ts(decompose(germany_gdp_ts), "germany_gdp")
my_plot.decomposed.ts(decompose(italy_gdp_ts), "italy_gdp")
my_plot.decomposed.ts(decompose(uk_gdp_ts), "uk_gdp")
my_plot.decomposed.ts(decompose(china_gdp_ts), "china_gdp")
my_plot.decomposed.ts(decompose(india_gdp_ts), "india_gdp")
my_plot.decomposed.ts(decompose(household_debt_ts), "household_debt")
my_plot.decomposed.ts(decompose(recession_indicator_ts), "recession_indicator")


## Apply DF Test
adf.test(building_permit_ts,
         alternative = "stationary",
         k = trunc((length(building_permit_ts) - 1) ^ (1 / 3)))$p.value
# Non stationary - hence taking differencing
adf.test(
  diff(log(abs(building_permit_ts))),
  alternative = "stationary"
  )$p.value
# Now building_permit_ts is stationary

adf.test(business_confidence_ts,
         alternative = "stationary",
         k = trunc((length(
           business_confidence_ts
         ) - 1) ^ (1 / 3)))$p.value
# Stationary

adf.test(consumer_confidence_ts,
         alternative = "stationary",
         k = trunc((length(
           consumer_confidence_ts
         ) - 1) ^ (1 / 3)))$p.value
# Non stationary - hence taking differencing

adf.test(
  diff(log(abs(consumer_confidence_ts))),
  alternative = "stationary")$p.value
# Stationary

adf.test(cpi_ts,
         alternative = "stationary",
         k = trunc((length(
           cpi_ts
         ) - 1) ^ (1 / 3)))$p.value
# Non stationary - hence taking differencing

adf.test(diff(log(abs(cpi_ts))),
         alternative = "stationary")$p.value
# Stationary

adf.test(crude_oil_ts, alternative = "stationary", k = trunc((length(crude_oil_ts) -
                                                                1) ^ (1 / 3)))$p.value
# Non stationary - hence taking differencing

adf.test(diff(log(abs(crude_oil_ts))),
         alternative = "stationary")$p.value
# Stationary

adf.test(gdp_ts, alternative = "stationary", k = trunc((length(gdp_ts) -
                                                          1) ^ (1 / 3)))$p.value
# Non stationary - hence taking differencing

adf.test(diff(log(abs(gdp_ts))),
         alternative = "stationary")$p.value
# Stationarity

adf.test(gold_monthly_ts, alternative = "stationary", k = trunc((length(gold_monthly_ts) -
                                                                   1) ^ (1 / 3)))$p.value
# Non stationary - hence taking differencing

adf.test(diff(log(abs(gold_monthly_ts))),
         alternative = "stationary")$p.value
# Stationarity

adf.test(housing_price_ts, alternative = "stationary", k = trunc((length(housing_price_ts) -
                                                                    1) ^ (1 / 3)))$p.value
#Stationary

adf.test(income_disposition_ts,
         alternative = "stationary",
         k = trunc((length(
           income_disposition_ts
         ) - 1) ^ (1 / 3)))$p.value
# Non stationary - hence taking differencing
adf.test(diff(log(abs(income_disposition_ts))),
  alternative = "stationary")$p.value
#Stationary

adf.test(industrial_production_ts,
         alternative = "stationary",
         k = trunc((length(
           industrial_production_ts
         ) - 1) ^ (1 / 3)))$p.value
# Non stationary - hence taking differencing

adf.test(
  diff(log(abs(industrial_production_ts))),
  alternative = "stationary")$p.value
# Stationary

adf.test(net_trade_ts, alternative = "stationary", k = trunc((length(net_trade_ts) -
                                                                1) ^ (1 / 3)))$p.value
# Non stationary - hence taking differencing
adf.test(diff(log(abs(net_trade_ts))),
         alternative = "stationary")$p.value
# Stationary

adf.test(nonfinancial_business_ts,
         alternative = "stationary",
         k = trunc((length(
           nonfinancial_business_ts
         ) - 1) ^ (1 / 3)))$p.value
# Non stationary - hence taking differencing
adf.test(
  diff(log(abs(nonfinancial_business_ts))),
  alternative = "stationary")$p.value
# Stationary

adf.test(production_ts, alternative = "stationary", k = trunc((length(production_ts) -
                                                                 1) ^ (1 / 3)))$p.value
# Non stationary - hence taking differencing
adf.test(diff(log(abs(production_ts))),
         alternative = "stationary")$p.value
# Statioanry

adf.test(sales_ts, alternative = "stationary", k = trunc((length(sales_ts) -
                                                            1) ^ (1 / 3)))$p.value
# Non stationary - hence taking differencing
adf.test(diff(log(abs(sales_ts))),
         alternative = "stationary")$p.value
# Stationary

adf.test(saving_rate_ts, alternative = "stationary", k = trunc((length(saving_rate_ts) -
                                                                  1) ^ (1 / 3)))$p.value
# Non stationary - hence taking differencing
adf.test(diff(log(abs(saving_rate_ts))),
         alternative = "stationary")$p.value
# Stationary

adf.test(share_price_ts, alternative = "stationary", k = trunc((length(share_price_ts) -
                                                                  1) ^ (1 / 3)))$p.value
# Non stationary - hence taking differencing
adf.test(diff(log(abs(share_price_ts))) ,
         alternative = "stationary")$p.value
# Stationary

adf.test(military_expense_ts,
         alternative = "stationary",
         k = trunc((length(
           military_expense_ts
         ) - 1) ^ (1 / 3)))$p.value
# Non stationary - hence taking differencing
adf.test(
  diff(log(abs(military_expense_ts))) ,
  alternative = "stationary")$p.value
# Stationary

adf.test(democrat_rule_ts, alternative = "stationary", k = trunc((length(democrat_rule_ts) -
                                                                    1) ^ (1 / 3)))$p.value
# Non stationary - hence taking differencing
adf.test(diff(democrat_rule_ts),
         alternative = "stationary")$p.value
# Stationary

adf.test(republican_rule_ts,
         alternative = "stationary",
         k = trunc((length(republican_rule_ts) - 1) ^ (1 / 3)))$p.value
# Non stationary - hence taking differencing
adf.test(diff(republican_rule_ts),
  alternative = "stationary")$p.value
# Stationary

adf.test(unemployment_rate_ts,
         alternative = "stationary",
         k = trunc((length(
           unemployment_rate_ts
         ) - 1) ^ (1 / 3)))$p.value
# Non stationary - hence taking differencing
adf.test(
  diff(log(abs(unemployment_rate_ts))),
  alternative = "stationary")$p.value
# Stationary

adf.test(us_inflow_ts, alternative = "stationary", k = trunc((length(us_inflow_ts) -
                                                                1) ^ (1 / 3)))$p.value
# Stationary

adf.test(us_outflow_ts, alternative = "stationary", k = trunc((length(us_outflow_ts) -
                                                                 1) ^ (1 / 3)))$p.value
# Non stationary - hence taking differencing
adf.test(diff(log(abs(us_outflow_ts))),
         alternative = "stationary")$p.value
# Stationary

adf.test(help_wanted_idx_ts,
         alternative = "stationary",
         k = trunc((length(help_wanted_idx_ts) - 1) ^ (1 / 3)))$p.value

# Non stationary - hence taking differencing

adf.test(
  diff(log(abs(help_wanted_idx_ts))),
  alternative = "stationary")$p.value

# Stationary

adf.test(
  diff(avg_employment_duration_week_ts, differences =  1),
  alternative = "stationary",
  k = trunc((
    length(avg_employment_duration_week_ts) - 1
  ) ^ (1 / 3))
)$p.value

#Stationary

adf.test(employment_insurance_claim_ts,
         alternative = "stationary",
         k = trunc((
           length(employment_insurance_claim_ts) - 1
         ) ^ (1 / 3)))$p.value
# Non stationary - hence taking differencing
adf.test(
  diff(log(abs(employment_insurance_claim_ts))),
  alternative = "stationary")$p.value
# Stationary

adf.test(eff_fed_fund_rate_ts,
         alternative = "stationary",
         k = trunc((length(
           eff_fed_fund_rate_ts
         ) - 1) ^ (1 / 3)))$p.value
# Non stationary - hence taking differencing

adf.test(
  diff(log(abs(eff_fed_fund_rate_ts))),
  alternative = "stationary")$p.value
# Stationary

adf.test(xchg_switz_us_curr_ts,
         alternative = "stationary",
         k = trunc((length(
           xchg_switz_us_curr_ts
         ) - 1) ^ (1 / 3)))$p.value
# Non stationary - hence taking differencing

adf.test(
  diff(log(abs(xchg_switz_us_curr_ts))),
  alternative = "stationary")$p.value

# Stationary

adf.test(xchg_jpn_us_curr_ts,
         alternative = "stationary",
         k = trunc((length(
           xchg_jpn_us_curr_ts
         ) - 1) ^ (1 / 3)))$p.value

# Non stationary - hence taking differencing

adf.test(
  diff(log(abs(xchg_jpn_us_curr_ts))),
  alternative = "stationary")$p.value
# Stationary

adf.test(xchg_uk_us_curr_ts,
         alternative = "stationary",
         k = trunc((length(xchg_uk_us_curr_ts) - 1) ^ (1 / 3)))$p.value
# Non stationary - hence taking differencing
adf.test(
  diff(log(abs(xchg_uk_us_curr_ts))),
  alternative = "stationary")$p.value
# Stationary

adf.test(xchg_cad_us_curr_ts,
         alternative = "stationary",
         k = trunc((length(
           xchg_cad_us_curr_ts
         ) - 1) ^ (1 / 3)))$p.value
# Non stationary - hence taking differencing

adf.test(
  diff(log(abs(xchg_cad_us_curr_ts))),
  alternative = "stationary")$p.value

# Stationary

adf.test(germany_recession_ts,
         alternative = "stationary",
         k = trunc((length(
           germany_recession_ts
         ) - 1) ^ (1 / 3)))$p.value
# Stationary

adf.test(italy_recession_ts,
         alternative = "stationary",
         k = trunc((length(italy_recession_ts) - 1) ^ (1 / 3)))$p.value
# Stationary

adf.test(france_recession_ts,
         alternative = "stationary",
         k = trunc((length(
           france_recession_ts
         ) - 1) ^ (1 / 3)))$p.value
# Stationary

adf.test(canada_recession_ts,
         alternative = "stationary",
         k = trunc((length(
           canada_recession_ts
         ) - 1) ^ (1 / 3)))$p.value
# Stationary

adf.test(japan_recession_ts,
         alternative = "stationary",
         k = trunc((length(japan_recession_ts) - 1) ^ (1 / 3)))$p.value
# Stationary

adf.test(uk_recession_ts, alternative = "stationary", k = trunc((length(uk_recession_ts) -
                                                                   1) ^ (1 / 3)))$p.value
# Stationary

adf.test(s_and_p_return_rate_ts,
         alternative = "stationary",
         k = trunc((length(
           s_and_p_return_rate_ts
         ) - 1) ^ (1 / 3)))$p.value
# Non stationary - hence taking differencing
adf.test(
  diff(log(abs(s_and_p_return_rate_ts))),
  alternative = "stationary")$p.value
# Stationary

adf.test(long_term_yield_rate_us_ts,
         alternative = "stationary",
         k = trunc((length(
           long_term_yield_rate_us_ts
         ) - 1) ^ (1 / 3)))$p.value
# Non stationary - hence taking differencing
adf.test(diff(log(abs(long_term_yield_rate_us_ts))),
  alternative = "stationary")$p.value
# Stationary

adf.test(long_term_yield_rate_germany_ts,
         alternative = "stationary",
         k = trunc((
           length(long_term_yield_rate_germany_ts) - 1
         ) ^ (1 / 3)))$p.value
# Non stationary - hence taking differencing
adf.test(
  diff(log(abs(long_term_yield_rate_germany_ts))),
  alternative = "stationary")$p.value
# Stationary


adf.test(long_term_yield_rate_canada_ts,
         alternative = "stationary",
         k = trunc((
           length(long_term_yield_rate_canada_ts) - 1
         ) ^ (1 / 3)))$p.value
# Non stationary - hence taking differencing
adf.test(
  diff(log(abs(long_term_yield_rate_canada_ts))),
  alternative = "stationary")$p.value
# Stationary


adf.test(long_term_yield_rate_france_ts,
         alternative = "stationary",
         k = trunc((
           length(long_term_yield_rate_france_ts) - 1
         ) ^ (1 / 3)))$p.value
# Non stationary - hence taking differencing
adf.test(
  diff(log(abs(long_term_yield_rate_france_ts))),
  alternative = "stationary")$p.value
# Stationary

adf.test(long_term_yield_rate_uk_ts,
         alternative = "stationary",
         k = trunc((length(
           long_term_yield_rate_uk_ts
         ) - 1) ^ (1 / 3)))$p.value
# Non stationary - hence taking differencing
adf.test(
  diff(log(abs(long_term_yield_rate_uk_ts))),
  alternative = "stationary")$p.value
# Stationary

adf.test(japan_gdp_ts,
         alternative = "stationary",
         k = trunc((length(japan_gdp_ts) - 1) ^ (1 / 3)))$p.value
# Stationary


adf.test(canada_gdp_ts, alternative = "stationary", k = trunc((length(canada_gdp_ts) -
                                                                 1) ^ (1 / 3)))$p.value
# Stationary

adf.test(france_gdp_ts, alternative = "stationary", k = trunc((length(france_gdp_ts) -
                                                                 1) ^ (1 / 3)))$p.value
# Stationary

adf.test(germany_gdp_ts, alternative = "stationary", k = trunc((length(germany_gdp_ts) -
                                                                  1) ^ (1 / 3)))$p.value
# Stationary

adf.test(italy_gdp_ts, alternative = "stationary", k = trunc((length(italy_gdp_ts) -
                                                                1) ^ (1 / 3)))$p.value
# Stationary

adf.test(uk_gdp_ts, alternative = "stationary", k = trunc((length(uk_gdp_ts) -
                                                             1) ^ (1 / 3)))$p.value
# Stationary

adf.test(china_gdp_ts, alternative = "stationary", k = trunc((length(china_gdp_ts) -
                                                                1) ^ (1 / 3)))$p.value
# Non stationary - hence taking differencing
adf.test(diff(log(abs(china_gdp_ts))),
         alternative = "stationary")$p.value
# Stationary

adf.test(india_gdp_ts, alternative = "stationary", k = trunc((length(india_gdp_ts) -
                                                                1) ^ (1 / 3)))$p.value
# Stationary

adf.test(household_debt_ts, alternative = "stationary", k = trunc((length(household_debt_ts) -
                                                                     1) ^ (1 / 3)))$p.value
# Non stationary - hence taking differencing
adf.test(diff(log(abs(household_debt_ts))),
         alternative = "stationary")$p.value
# Stationary


adf.test(recession_indicator_ts,
         alternative = "stationary",
         k = trunc((length(
           recession_indicator_ts
         ) - 1) ^ (1 / 3)))$p.value
# Stationary

# Forecasting:

forecast_period <- 240


# Created data with transformation with stationary series:

#### ==========================================

# Convert to XTS object

master_data_xts <-
  xts(master_data[,-1], order.by = master_data[, 1])


# We create the complete date vector (with historical and forecast)

dates <-
  seq(
    start(master_data_xts),
    by = "month",
    length.out = nrow(master_data_xts) + forecast_period
  )



last_date_of_historical <- end(master_data_xts)

num_columns <- ncol(master_data) - 1
num_dates    <- nrow(master_data) + forecast_period

recession_plot <- data.frame(matrix(0, num_dates, num_columns))
#View(recession_plot)

row.names(recession_plot) <- dates

#View(recession_plot)

# Auto Arima Custom Function

building_permit_val <-
  auto.arima(master_data$building_permit_val)
pred.building_permit_val <-
  forecast(building_permit_val, h = forecast_period)
building_permit_val_plot <-
  cbind(pred.building_permit_val$fitted,
        pred.building_permit_val$mean)
for (j in 1:num_dates) {
  if (is.na(building_permit_val_plot[j, 1])) {
    recession_plot[j, 1] <-
      building_permit_val_plot[j, 2]
  } else{
    recession_plot[j, 1] <- building_permit_val_plot[j, 1]
  }
}

business_confidence_val <-
  auto.arima(master_data$business_confidence_val)
pred.business_confidence_val <-
  forecast(business_confidence_val, h = forecast_period)
business_confidence_val_plot <-
  cbind(pred.business_confidence_val$fitted,
        pred.business_confidence_val$mean)
for (j in 1:num_dates) {
  if (is.na(business_confidence_val_plot[j, 1])) {
    recession_plot[j, 2] <-
      business_confidence_val_plot[j, 2]
  } else{
    recession_plot[j, 2] <- business_confidence_val_plot[j, 1]
  }
}
#### --------
consumer_confidence_val <-
  auto.arima(master_data$consumer_confidence_val)
pred.consumer_confidence_val <-
  forecast(consumer_confidence_val, h = forecast_period)
consumer_confidence_val_plot <-
  cbind(pred.consumer_confidence_val$fitted,
        pred.consumer_confidence_val$mean)
for (j in 1:num_dates) {
  if (is.na(consumer_confidence_val_plot[j, 1])) {
    recession_plot[j, 3] <-
      consumer_confidence_val_plot[j, 2]
  } else{
    recession_plot[j, 3] <- consumer_confidence_val_plot[j, 1]
  }
}
#### --------
cpi_val <- auto.arima(master_data$cpi_val)
pred.cpi_val <- forecast(cpi_val, h = forecast_period)
cpi_val_plot <- cbind(pred.cpi_val$fitted, pred.cpi_val$mean)
for (j in 1:num_dates) {
  if (is.na(cpi_val_plot[j, 1])) {
    recession_plot[j, 4] <-
      cpi_val_plot[j, 2]
  } else{
    recession_plot[j, 4] <- cpi_val_plot[j, 1]
  }
}
#### --------
crude_oil_val <- auto.arima(master_data$crude_oil_val)
pred.crude_oil_val <- forecast(crude_oil_val, h = forecast_period)
crude_oil_val_plot <-
  cbind(pred.crude_oil_val$fitted, pred.crude_oil_val$mean)
for (j in 1:num_dates) {
  if (is.na(crude_oil_val_plot[j, 1])) {
    recession_plot[j, 5] <-
      crude_oil_val_plot[j, 2]
  } else{
    recession_plot[j, 5] <- crude_oil_val_plot[j, 1]
  }
}
#### --------
gdp_val <- auto.arima(master_data$gdp_val)
pred.gdp_val <- forecast(gdp_val, h = forecast_period)
gdp_val_plot <- cbind(pred.gdp_val$fitted, pred.gdp_val$mean)
for (j in 1:num_dates) {
  if (is.na(gdp_val_plot[j, 1])) {
    recession_plot[j, 6] <-
      gdp_val_plot[j, 2]
  } else{
    recession_plot[j, 6] <- gdp_val_plot[j, 1]
  }
}
#### --------
gold_monthly_val <- auto.arima(master_data$gold_monthly_val)
pred.gold_monthly_val <-
  forecast(gold_monthly_val, h = forecast_period)
gold_monthly_val_plot <-
  cbind(pred.gold_monthly_val$fitted, pred.gold_monthly_val$mean)
for (j in 1:num_dates) {
  if (is.na(gold_monthly_val_plot[j, 1])) {
    recession_plot[j, 7] <-
      gold_monthly_val_plot[j, 2]
  } else{
    recession_plot[j, 7] <- gold_monthly_val_plot[j, 1]
  }
}
#### --------
housing_price_val <- auto.arima(master_data$housing_price_val)
pred.housing_price_val <-
  forecast(housing_price_val, h = forecast_period)
housing_price_val_plot <-
  cbind(pred.housing_price_val$fitted, pred.housing_price_val$mean)
for (j in 1:num_dates) {
  if (is.na(housing_price_val_plot[j, 1])) {
    recession_plot[j, 8] <-
      housing_price_val_plot[j, 2]
  } else{
    recession_plot[j, 8] <- housing_price_val_plot[j, 1]
  }
}
#### --------
income_disposition_val <-
  auto.arima(master_data$income_disposition_val)
pred.income_disposition_val <-
  forecast(income_disposition_val, h = forecast_period)
income_disposition_val_plot <-
  cbind(pred.income_disposition_val$fitted,
        pred.income_disposition_val$mean)
for (j in 1:num_dates) {
  if (is.na(income_disposition_val_plot[j, 1])) {
    recession_plot[j, 9] <-
      income_disposition_val_plot[j, 2]
  } else{
    recession_plot[j, 9] <- income_disposition_val_plot[j, 1]
  }
}
#### --------
industrial_production_val <-
  auto.arima(master_data$industrial_production_val)
pred.industrial_production_val <-
  forecast(industrial_production_val, h = forecast_period)
industrial_production_val_plot <-
  cbind(pred.industrial_production_val$fitted,
        pred.industrial_production_val$mean)
for (j in 1:num_dates) {
  if (is.na(industrial_production_val_plot[j, 1])) {
    recession_plot[j, 10] <-
      industrial_production_val_plot[j, 2]
  } else{
    recession_plot[j, 10] <- industrial_production_val_plot[j, 1]
  }
}
#### --------
net_trade_val <- auto.arima(master_data$net_trade_val)
pred.net_trade_val <- forecast(net_trade_val, h = forecast_period)
net_trade_val_plot <-
  cbind(pred.net_trade_val$fitted, pred.net_trade_val$mean)
for (j in 1:num_dates) {
  if (is.na(net_trade_val_plot[j, 1])) {
    recession_plot[j, 11] <-
      net_trade_val_plot[j, 2]
  } else{
    recession_plot[j, 11] <- net_trade_val_plot[j, 1]
  }
}
#### --------
nonfinancial_business_val <-
  auto.arima(master_data$nonfinancial_business_val)
pred.nonfinancial_business_val <-
  forecast(nonfinancial_business_val, h = forecast_period)
nonfinancial_business_val_plot <-
  cbind(pred.nonfinancial_business_val$fitted,
        pred.nonfinancial_business_val$mean)
for (j in 1:num_dates) {
  if (is.na(nonfinancial_business_val_plot[j, 1])) {
    recession_plot[j, 12] <-
      nonfinancial_business_val_plot[j, 2]
  } else{
    recession_plot[j, 12] <- nonfinancial_business_val_plot[j, 1]
  }
}
#### --------
production_val <- auto.arima(master_data$production_val)
pred.production_val <- forecast(production_val, h = forecast_period)
production_val_plot <-
  cbind(pred.production_val$fitted, pred.production_val$mean)
for (j in 1:num_dates) {
  if (is.na(production_val_plot[j, 1])) {
    recession_plot[j, 13] <-
      production_val_plot[j, 2]
  } else{
    recession_plot[j, 13] <- production_val_plot[j, 1]
  }
}
#### --------
sales_val <- auto.arima(master_data$sales_val)
pred.sales_val <- forecast(sales_val, h = forecast_period)
sales_val_plot <- cbind(pred.sales_val$fitted, pred.sales_val$mean)
for (j in 1:num_dates) {
  if (is.na(sales_val_plot[j, 1])) {
    recession_plot[j, 14] <-
      sales_val_plot[j, 2]
  } else{
    recession_plot[j, 14] <- sales_val_plot[j, 1]
  }
}
#### --------
saving_rate_val <- auto.arima(master_data$saving_rate_val)
pred.saving_rate_val <-
  forecast(saving_rate_val, h = forecast_period)
saving_rate_val_plot <-
  cbind(pred.saving_rate_val$fitted, pred.saving_rate_val$mean)
for (j in 1:num_dates) {
  if (is.na(saving_rate_val_plot[j, 1])) {
    recession_plot[j, 15] <-
      saving_rate_val_plot[j, 2]
  } else{
    recession_plot[j, 15] <- saving_rate_val_plot[j, 1]
  }
}
#### --------
share_price_val <- auto.arima(master_data$share_price_val)
pred.share_price_val <-
  forecast(share_price_val, h = forecast_period)
share_price_val_plot <-
  cbind(pred.share_price_val$fitted, pred.share_price_val$mean)
for (j in 1:num_dates) {
  if (is.na(share_price_val_plot[j, 1])) {
    recession_plot[j, 16] <-
      share_price_val_plot[j, 2]
  } else{
    recession_plot[j, 16] <- share_price_val_plot[j, 1]
  }
}
#### --------
military_expense_val <-
  auto.arima(master_data$military_expense_val)
pred.military_expense_val <-
  forecast(military_expense_val, h = forecast_period)
military_expense_val_plot <-
  cbind(pred.military_expense_val$fitted,
        pred.military_expense_val$mean)
for (j in 1:num_dates) {
  if (is.na(military_expense_val_plot[j, 1])) {
    recession_plot[j, 17] <-
      military_expense_val_plot[j, 2]
  } else{
    recession_plot[j, 17] <- military_expense_val_plot[j, 1]
  }
}
#### --------
democrat_rule <- auto.arima(master_data$democrat_rule)
pred.democrat_rule <- forecast(democrat_rule, h = forecast_period)
democrat_rule_plot <-
  cbind(pred.democrat_rule$fitted, pred.democrat_rule$mean)
for (j in 1:num_dates) {
  if (is.na(democrat_rule_plot[j, 1])) {
    recession_plot[j, 18] <-
      democrat_rule_plot[j, 2]
  } else{
    recession_plot[j, 18] <- democrat_rule_plot[j, 1]
  }
}
#### --------
republican_rule <- auto.arima(master_data$republican_rule)
pred.republican_rule <-
  forecast(republican_rule, h = forecast_period)
republican_rule_plot <-
  cbind(pred.republican_rule$fitted, pred.republican_rule$mean)
for (j in 1:num_dates) {
  if (is.na(republican_rule_plot[j, 1])) {
    recession_plot[j, 19] <-
      republican_rule_plot[j, 2]
  } else{
    recession_plot[j, 19] <- republican_rule_plot[j, 1]
  }
}
#### --------
unemployment_rate <- auto.arima(master_data$unemployment_rate)
pred.unemployment_rate <-
  forecast(unemployment_rate, h = forecast_period)
unemployment_rate_plot <-
  cbind(pred.unemployment_rate$fitted, pred.unemployment_rate$mean)
for (j in 1:num_dates) {
  if (is.na(unemployment_rate_plot[j, 1])) {
    recession_plot[j, 20] <-
      unemployment_rate_plot[j, 2]
  } else{
    recession_plot[j, 20] <- unemployment_rate_plot[j, 1]
  }
}
#### --------
us_inflow_val <- auto.arima(master_data$us_inflow_val)
pred.us_inflow_val <- forecast(us_inflow_val, h = forecast_period)
us_inflow_val_plot <-
  cbind(pred.us_inflow_val$fitted, pred.us_inflow_val$mean)
for (j in 1:num_dates) {
  if (is.na(us_inflow_val_plot[j, 1])) {
    recession_plot[j, 21] <-
      us_inflow_val_plot[j, 2]
  } else{
    recession_plot[j, 21] <- us_inflow_val_plot[j, 1]
  }
}
#### --------
us_outflow_val <- auto.arima(master_data$us_outflow_val)
pred.us_outflow_val <- forecast(us_outflow_val, h = forecast_period)
us_outflow_val_plot <-
  cbind(pred.us_outflow_val$fitted, pred.us_outflow_val$mean)
for (j in 1:num_dates) {
  if (is.na(us_outflow_val_plot[j, 1])) {
    recession_plot[j, 22] <-
      us_outflow_val_plot[j, 2]
  } else{
    recession_plot[j, 22] <- us_outflow_val_plot[j, 1]
  }
}
#### --------
help_wanted_idx <- auto.arima(master_data$help_wanted_idx)
pred.help_wanted_idx <-
  forecast(help_wanted_idx, h = forecast_period)
help_wanted_idx_plot <-
  cbind(pred.help_wanted_idx$fitted, pred.help_wanted_idx$mean)
for (j in 1:num_dates) {
  if (is.na(help_wanted_idx_plot[j, 1])) {
    recession_plot[j, 23] <-
      help_wanted_idx_plot[j, 2]
  } else{
    recession_plot[j, 23] <- help_wanted_idx_plot[j, 1]
  }
}
#### --------
avg_employment_duration_week <-
  auto.arima(master_data$avg_employment_duration_week)
pred.avg_employment_duration_week <-
  forecast(avg_employment_duration_week, h = forecast_period)
avg_employment_duration_week_plot <-
  cbind(
    pred.avg_employment_duration_week$fitted,
    pred.avg_employment_duration_week$mean
  )
for (j in 1:num_dates) {
  if (is.na(avg_employment_duration_week_plot[j, 1])) {
    recession_plot[j, 24] <-
      avg_employment_duration_week_plot[j, 2]
  } else{
    recession_plot[j, 24] <- avg_employment_duration_week_plot[j, 1]
  }
}
#### --------
employment_insurance_claim <-
  auto.arima(master_data$employment_insurance_claim)
pred.employment_insurance_claim <-
  forecast(employment_insurance_claim, h = forecast_period)
employment_insurance_claim_plot <-
  cbind(pred.employment_insurance_claim$fitted,
        pred.employment_insurance_claim$mean)
for (j in 1:num_dates) {
  if (is.na(employment_insurance_claim_plot[j, 1])) {
    recession_plot[j, 25] <-
      employment_insurance_claim_plot[j, 2]
  } else{
    recession_plot[j, 25] <- employment_insurance_claim_plot[j, 1]
  }
}
#### --------
eff_fed_fund_rate <- auto.arima(master_data$eff_fed_fund_rate)
pred.eff_fed_fund_rate <-
  forecast(eff_fed_fund_rate, h = forecast_period)
eff_fed_fund_rate_plot <-
  cbind(pred.eff_fed_fund_rate$fitted, pred.eff_fed_fund_rate$mean)
for (j in 1:num_dates) {
  if (is.na(eff_fed_fund_rate_plot[j, 1])) {
    recession_plot[j, 26] <-
      eff_fed_fund_rate_plot[j, 2]
  } else{
    recession_plot[j, 26] <- eff_fed_fund_rate_plot[j, 1]
  }
}
#### --------
xchg_switz_us_curr <-
  auto.arima(master_data$xchg_switz_us_curr)
pred.xchg_switz_us_curr <-
  forecast(xchg_switz_us_curr, h = forecast_period)
xchg_switz_us_curr_plot <-
  cbind(pred.xchg_switz_us_curr$fitted,
        pred.xchg_switz_us_curr$mean)
for (j in 1:num_dates) {
  if (is.na(xchg_switz_us_curr_plot[j, 1])) {
    recession_plot[j, 27] <-
      xchg_switz_us_curr_plot[j, 2]
  } else{
    recession_plot[j, 27] <- xchg_switz_us_curr_plot[j, 1]
  }
}
#### --------
xchg_jpn_us_curr <- auto.arima(master_data$xchg_jpn_us_curr)
pred.xchg_jpn_us_curr <-
  forecast(xchg_jpn_us_curr, h = forecast_period)
xchg_jpn_us_curr_plot <-
  cbind(pred.xchg_jpn_us_curr$fitted, pred.xchg_jpn_us_curr$mean)
for (j in 1:num_dates) {
  if (is.na(xchg_jpn_us_curr_plot[j, 1])) {
    recession_plot[j, 28] <-
      xchg_jpn_us_curr_plot[j, 2]
  } else{
    recession_plot[j, 28] <- xchg_jpn_us_curr_plot[j, 1]
  }
}
#### --------
xchg_uk_us_curr <- auto.arima(master_data$xchg_uk_us_curr)
pred.xchg_uk_us_curr <-
  forecast(xchg_uk_us_curr, h = forecast_period)
xchg_uk_us_curr_plot <-
  cbind(pred.xchg_uk_us_curr$fitted, pred.xchg_uk_us_curr$mean)
for (j in 1:num_dates) {
  if (is.na(xchg_uk_us_curr_plot[j, 1])) {
    recession_plot[j, 29] <-
      xchg_uk_us_curr_plot[j, 2]
  } else{
    recession_plot[j, 29] <- xchg_uk_us_curr_plot[j, 1]
  }
}
#### --------
xchg_cad_us_curr <- auto.arima(master_data$xchg_cad_us_curr)
pred.xchg_cad_us_curr <-
  forecast(xchg_cad_us_curr, h = forecast_period)
xchg_cad_us_curr_plot <-
  cbind(pred.xchg_cad_us_curr$fitted, pred.xchg_cad_us_curr$mean)
for (j in 1:num_dates) {
  if (is.na(xchg_cad_us_curr_plot[j, 1])) {
    recession_plot[j, 30] <-
      xchg_cad_us_curr_plot[j, 2]
  } else{
    recession_plot[j, 30] <- xchg_cad_us_curr_plot[j, 1]
  }
}
#### --------
germany_recession <- auto.arima(master_data$germany_recession)
pred.germany_recession <-
  forecast(germany_recession, h = forecast_period)
germany_recession_plot <-
  cbind(pred.germany_recession$fitted, pred.germany_recession$mean)
for (j in 1:num_dates) {
  if (is.na(germany_recession_plot[j, 1])) {
    recession_plot[j, 31] <-
      germany_recession_plot[j, 2]
  } else{
    recession_plot[j, 31] <- germany_recession_plot[j, 1]
  }
}
#### --------
italy_recession <- auto.arima(master_data$italy_recession)
pred.italy_recession <-
  forecast(italy_recession, h = forecast_period)
italy_recession_plot <-
  cbind(pred.italy_recession$fitted, pred.italy_recession$mean)
for (j in 1:num_dates) {
  if (is.na(italy_recession_plot[j, 1])) {
    recession_plot[j, 32] <-
      italy_recession_plot[j, 2]
  } else{
    recession_plot[j, 32] <- italy_recession_plot[j, 1]
  }
}
#### --------
france_recession <- auto.arima(master_data$france_recession)
pred.france_recession <-
  forecast(france_recession, h = forecast_period)
france_recession_plot <-
  cbind(pred.france_recession$fitted, pred.france_recession$mean)
for (j in 1:num_dates) {
  if (is.na(france_recession_plot[j, 1])) {
    recession_plot[j, 33] <-
      france_recession_plot[j, 2]
  } else{
    recession_plot[j, 33] <- france_recession_plot[j, 1]
  }
}
#### --------
canada_recession <- auto.arima(master_data$canada_recession)
pred.canada_recession <-
  forecast(canada_recession, h = forecast_period)
canada_recession_plot <-
  cbind(pred.canada_recession$fitted, pred.canada_recession$mean)
for (j in 1:num_dates) {
  if (is.na(canada_recession_plot[j, 1])) {
    recession_plot[j, 34] <-
      canada_recession_plot[j, 2]
  } else{
    recession_plot[j, 34] <- canada_recession_plot[j, 1]
  }
}
#### --------
japan_recession <- auto.arima(master_data$japan_recession)
pred.japan_recession <-
  forecast(japan_recession, h = forecast_period)
japan_recession_plot <-
  cbind(pred.japan_recession$fitted, pred.japan_recession$mean)
for (j in 1:num_dates) {
  if (is.na(japan_recession_plot[j, 1])) {
    recession_plot[j, 35] <-
      japan_recession_plot[j, 2]
  } else{
    recession_plot[j, 35] <- japan_recession_plot[j, 1]
  }
}
#### --------
uk_recession <- auto.arima(master_data$uk_recession)
pred.uk_recession <- forecast(uk_recession, h = forecast_period)
uk_recession_plot <-
  cbind(pred.uk_recession$fitted, pred.uk_recession$mean)
for (j in 1:num_dates) {
  if (is.na(uk_recession_plot[j, 1])) {
    recession_plot[j, 36] <-
      uk_recession_plot[j, 2]
  } else{
    recession_plot[j, 36] <- uk_recession_plot[j, 1]
  }
}
#### --------
s_and_p_return_rate <-
  auto.arima(master_data$s_and_p_return_rate)
pred.s_and_p_return_rate <-
  forecast(s_and_p_return_rate, h = forecast_period)
s_and_p_return_rate_plot <-
  cbind(pred.s_and_p_return_rate$fitted,
        pred.s_and_p_return_rate$mean)
for (j in 1:num_dates) {
  if (is.na(s_and_p_return_rate_plot[j, 1])) {
    recession_plot[j, 37] <-
      s_and_p_return_rate_plot[j, 2]
  } else{
    recession_plot[j, 37] <- s_and_p_return_rate_plot[j, 1]
  }
}
#### --------
long_term_yield_rate_us <-
  auto.arima(master_data$long_term_yield_rate_us)
pred.long_term_yield_rate_us <-
  forecast(long_term_yield_rate_us, h = forecast_period)
long_term_yield_rate_us_plot <-
  cbind(pred.long_term_yield_rate_us$fitted,
        pred.long_term_yield_rate_us$mean)
for (j in 1:num_dates) {
  if (is.na(long_term_yield_rate_us_plot[j, 1])) {
    recession_plot[j, 38] <-
      long_term_yield_rate_us_plot[j, 2]
  } else{
    recession_plot[j, 38] <- long_term_yield_rate_us_plot[j, 1]
  }
}
#### --------
long_term_yield_rate_germany <-
  auto.arima(master_data$long_term_yield_rate_germany)
pred.long_term_yield_rate_germany <-
  forecast(long_term_yield_rate_germany, h = forecast_period)
long_term_yield_rate_germany_plot <-
  cbind(
    pred.long_term_yield_rate_germany$fitted,
    pred.long_term_yield_rate_germany$mean
  )
for (j in 1:num_dates) {
  if (is.na(long_term_yield_rate_germany_plot[j, 1])) {
    recession_plot[j, 39] <-
      long_term_yield_rate_germany_plot[j, 2]
  } else{
    recession_plot[j, 39] <- long_term_yield_rate_germany_plot[j, 1]
  }
}
#### --------
long_term_yield_rate_canada <-
  auto.arima(master_data$long_term_yield_rate_canada)
pred.long_term_yield_rate_canada <-
  forecast(long_term_yield_rate_canada, h = forecast_period)
long_term_yield_rate_canada_plot <-
  cbind(pred.long_term_yield_rate_canada$fitted,
        pred.long_term_yield_rate_canada$mean)
for (j in 1:num_dates) {
  if (is.na(long_term_yield_rate_canada_plot[j, 1])) {
    recession_plot[j, 40] <-
      long_term_yield_rate_canada_plot[j, 2]
  } else{
    recession_plot[j, 40] <- long_term_yield_rate_canada_plot[j, 1]
  }
}
#### --------
long_term_yield_rate_france <-
  auto.arima(master_data$long_term_yield_rate_france)
pred.long_term_yield_rate_france <-
  forecast(long_term_yield_rate_france, h = forecast_period)
long_term_yield_rate_france_plot <-
  cbind(pred.long_term_yield_rate_france$fitted,
        pred.long_term_yield_rate_france$mean)
for (j in 1:num_dates) {
  if (is.na(long_term_yield_rate_france_plot[j, 1])) {
    recession_plot[j, 41] <-
      long_term_yield_rate_france_plot[j, 2]
  } else{
    recession_plot[j, 41] <- long_term_yield_rate_france_plot[j, 1]
  }
}
#### --------
long_term_yield_rate_uk <-
  auto.arima(master_data$long_term_yield_rate_uk)
pred.long_term_yield_rate_uk <-
  forecast(long_term_yield_rate_uk, h = forecast_period)
long_term_yield_rate_uk_plot <-
  cbind(pred.long_term_yield_rate_uk$fitted,
        pred.long_term_yield_rate_uk$mean)
for (j in 1:num_dates) {
  if (is.na(long_term_yield_rate_uk_plot[j, 1])) {
    recession_plot[j, 42] <-
      long_term_yield_rate_uk_plot[j, 2]
  } else{
    recession_plot[j, 42] <- long_term_yield_rate_uk_plot[j, 1]
  }
}
#### --------
japan_gdp <- auto.arima(master_data$japan_gdp)
pred.japan_gdp <- forecast(japan_gdp, h = forecast_period)
japan_gdp_plot <-
  cbind(pred.japan_gdp$fitted, pred.japan_gdp$mean)
for (j in 1:num_dates) {
  if (is.na(japan_gdp_plot[j, 1])) {
    recession_plot[j, 43] <-
      japan_gdp_plot[j, 2]
  } else{
    recession_plot[j, 43] <- japan_gdp_plot[j, 1]
  }
}
#### --------
canada_gdp <- auto.arima(master_data$canada_gdp)
pred.canada_gdp <- forecast(canada_gdp, h = forecast_period)
canada_gdp_plot <-
  cbind(pred.canada_gdp$fitted, pred.canada_gdp$mean)
for (j in 1:num_dates) {
  if (is.na(canada_gdp_plot[j, 1])) {
    recession_plot[j, 44] <-
      canada_gdp_plot[j, 2]
  } else{
    recession_plot[j, 44] <- canada_gdp_plot[j, 1]
  }
}
#### --------
france_gdp <- auto.arima(master_data$france_gdp)
pred.france_gdp <- forecast(france_gdp, h = forecast_period)
france_gdp_plot <-
  cbind(pred.france_gdp$fitted, pred.france_gdp$mean)
for (j in 1:num_dates) {
  if (is.na(france_gdp_plot[j, 1])) {
    recession_plot[j, 45] <-
      france_gdp_plot[j, 2]
  } else{
    recession_plot[j, 45] <- france_gdp_plot[j, 1]
  }
}
#### --------
germany_gdp <- auto.arima(master_data$germany_gdp)
pred.germany_gdp <- forecast(germany_gdp, h = forecast_period)
germany_gdp_plot <-
  cbind(pred.germany_gdp$fitted, pred.germany_gdp$mean)
for (j in 1:num_dates) {
  if (is.na(germany_gdp_plot[j, 1])) {
    recession_plot[j, 46] <-
      germany_gdp_plot[j, 2]
  } else{
    recession_plot[j, 46] <- germany_gdp_plot[j, 1]
  }
}
#### --------
italy_gdp <- auto.arima(master_data$italy_gdp)
pred.italy_gdp <- forecast(italy_gdp, h = forecast_period)
italy_gdp_plot <- cbind(pred.italy_gdp$fitted, pred.italy_gdp$mean)
for (j in 1:num_dates) {
  if (is.na(italy_gdp_plot[j, 1])) {
    recession_plot[j, 47] <-
      italy_gdp_plot[j, 2]
  } else{
    recession_plot[j, 47] <- italy_gdp_plot[j, 1]
  }
}
#### --------
uk_gdp <- auto.arima(master_data$uk_gdp)
pred.uk_gdp <- forecast(uk_gdp, h = forecast_period)
uk_gdp_plot <- cbind(pred.uk_gdp$fitted, pred.uk_gdp$mean)
for (j in 1:num_dates) {
  if (is.na(uk_gdp_plot[j, 1])) {
    recession_plot[j, 48] <-
      uk_gdp_plot[j, 2]
  } else{
    recession_plot[j, 48] <- uk_gdp_plot[j, 1]
  }
}
#### --------
china_gdp <- auto.arima(master_data$china_gdp)
pred.china_gdp <- forecast(china_gdp, h = forecast_period)
china_gdp_plot <- cbind(pred.china_gdp$fitted, pred.china_gdp$mean)
for (j in 1:num_dates) {
  if (is.na(china_gdp_plot[j, 1])) {
    recession_plot[j, 49] <-
      china_gdp_plot[j, 2]
  } else{
    recession_plot[j, 49] <- china_gdp_plot[j, 1]
  }
}
#### --------
india_gdp <- auto.arima(master_data$india_gdp)
pred.india_gdp <- forecast(india_gdp, h = forecast_period)
india_gdp_plot <- cbind(pred.india_gdp$fitted, pred.india_gdp$mean)
for (j in 1:num_dates) {
  if (is.na(india_gdp_plot[j, 1])) {
    recession_plot[j, 50] <-
      india_gdp_plot[j, 2]
  } else{
    recession_plot[j, 50] <- india_gdp_plot[j, 1]
  }
}
#### --------
household_debt_val <-
  auto.arima(master_data$household_debt_val)
pred.household_debt_val <-
  forecast(household_debt_val, h = forecast_period)
household_debt_val_plot <-
  cbind(pred.household_debt_val$fitted,
        pred.household_debt_val$mean)
for (j in 1:num_dates) {
  if (is.na(household_debt_val_plot[j, 1])) {
    recession_plot[j, 51] <-
      household_debt_val_plot[j, 2]
  } else{
    recession_plot[j, 51] <- household_debt_val_plot[j, 1]
  }
}
