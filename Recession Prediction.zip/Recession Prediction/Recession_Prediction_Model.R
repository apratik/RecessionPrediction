## Clearing Objects
rm(list = ls())

# Importing Library

suppressPackageStartupMessages({
  if (!require("stargazer"))
    install.packages("stargazer")
  library(stargazer)
  if (!require("gbm"))
    install.packages("gbm")
  library(gbm)
  if (!require("Information"))
    install.packages("Information")
  library(Information)
  if (!require("factoextra"))
    install.packages("factoextra")
  library(factoextra)
  if (!require("ggfortify"))
    install.packages("ggfortify")
  library(ggfortify)
  if (!require("r2d3"))
    install.packages("r2d3")
  library(r2d3)
  if (!require("devtools"))
    install.packages("devtools")
  library(devtools)
  if (!require("DataExplorer"))
    install.packages("DataExplorer")
  library(DataExplorer)
  if (!require("caret"))
    install.packages("caret")
  library(caret)
  if (!require("rpart"))
    install.packages("rpart")
  library(rpart)
  if (!require("rpart.plot"))
    install.packages("rpart.plot")
  library(rpart.plot)
  if (!require("rattle"))
    install.packages("rattle")
  library(rattle)
  if (!require("RColorBrewer"))
    install.packages("RColorBrewer")
  library(RColorBrewer)
  if (!require("party"))
    install.packages("party")
  library(party)
  if (!require("partykit"))
    install.packages("partykit")
  library(partykit)
  if (!require("dplyr"))
    install.packages("dplyr")
  library(dplyr)
  if (!require("zoo"))
    install.packages("zoo")
  library(zoo)
  if (!require("scales"))
    install.packages("scales")
  library(scales)
  if (!require("colorspace"))
    install.packages("colorspace")
  library(colorspace)
  if (!require("varImp"))
    install.packages("varImp")
  library(varImp)
  if (!require("earth"))
    install.packages("earth")
  library(earth)
  if (!require("MASS"))
    install.packages("MASS")
  library(MASS)
  if (!require("car"))
    install.packages("car")
  library(car)
  if (!require("Quandl"))
    install.packages("Quandl")
  library(Quandl)
  if (!require("forecast"))
    install.packages("forecast")
  library(forecast)
  if (!require("e1071"))
    install.packages("e1071")
  library(e1071)
  if (!require("quantmod"))
    install.packages("quantmod")
  library(quantmod)
  if (!require("xts"))
    install.packages("xts")
  library(xts)
  if (!require("TTR"))
    install.packages("TTR")
  library(TTR)
  if (!require("ggplot2"))
    install.packages("ggplot2")
  library(ggplot2)
  if (!require("cowplot"))
    install.packages("cowplot")
  library(cowplot)
  if (!require("RColorBrewer"))
    install.packages("RColorBrewer")
  library(RColorBrewer)
  if (!require("tseries"))
    install.packages("tseries")
  library(tseries)
  if (!require("lubridate"))
    install.packages("lubridate")
  library(lubridate)
  if (!require("ClustOfVar"))
    install.packages("ClustOfVar")
  library(ClustOfVar)
  if (!require("reshape2"))
    install.packages("reshape2")
  library(reshape2)
  if (!require("plyr"))
    install.packages("plyr")
  library(plyr)
  if (!require("Boruta"))
    install.packages("Boruta")
  library(Boruta)
  if (!require("inspectdf"))
    install.packages("inspectdf")
  library(inspectdf)
  if (!require("tidyverse"))
    install.packages("tidyverse")
  library(tidyverse)
  if (!require("readr"))
    install.packages("readr")
  library(readr)
  if (!require("Rdimtools"))
    install.packages("Rdimtools")
  library(Rdimtools)
  if (!require("corrr"))
    install.packages("corrr")
  library(corrr)
  if (!require("rAverage"))
    install.packages("rAverage")
  library(rAverage)
  if (!require("arm"))
    install.packages("arm")
  library(arm)
  if (!require("outliers"))
    install.packages("outliers")
  library(outliers)
})

library(xgboost)
library(readr)
library(stringr)


# Yearly/Quarterly To Monthly Conversion

convert_to_monthly_data <- function(input_df) {
  zd <- read.zoo(input_df, index.column = 1)
  tt <- as.yearmon(seq(start(zd), end(zd), "month"))
  zm <- na.spline(zd, as.yearmon, xout = tt)
  output_df <- fortify.zoo(zm)
}


# GDP (2007 index as 100)
# U.S. Bureau of Economic Analysis, Gross Domestic Product [GDP], retrieved from FRED, Federal Reserve Bank of St. Louis; https://fred.stlouisfed.org/series/GDP, November 30, 2019.

gdp_quarterly <-
  read.csv(
    file = "gdp-percent-change-quarterly.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

gdp <- convert_to_monthly_data(gdp_quarterly)

remove(gdp_quarterly)

names(gdp)[1] <- "Time"
names(gdp)[2] <- "gdp_val"

summary(gdp)

# Income and Disposition
# OECD (2019), Household disposable income (indicator). doi: 10.1787/dd50eddd-en (Accessed on 30 November 2019)

income_disposition_monthly <-
  read.csv(
    file = "income_disposition_monthly.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

income_disposition <-
  convert_to_monthly_data(income_disposition_monthly)

names(income_disposition)[1] <- "Time"
names(income_disposition)[2] <- "income_disposition_val"

summary(income_disposition)

remove(income_disposition_monthly)

# nonfinancial_business_quarterly (2007 index as 100)
# U.S. Bureau of Economic Analysis, Gross value added of nonfinancial corporate business [A455RC1Q027SBEA], retrieved from FRED, Federal Reserve Bank of St. Louis; https://fred.stlouisfed.org/series/A455RC1Q027SBEA, November 30, 2019.

nonfinancial_business_quarterly <-
  read.csv(
    file = "nonfinancial_business_quarterly.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

nonfinancial_business <-
  convert_to_monthly_data(nonfinancial_business_quarterly)

names(nonfinancial_business)[1] <- "Time"

names(nonfinancial_business)[2] <- "nonfinancial_business_val"

# View(nonfinancial_business)

remove(nonfinancial_business_quarterly)

# Crude Oil
# Federal Reserve Bank of St. Louis, Spot Crude Oil Price: West Texas Intermediate (WTI) [WTISPLC], retrieved from FRED, Federal Reserve Bank of St. Louis; https://fred.stlouisfed.org/series/WTISPLC, November 30, 2019.

crude_oil_monthly <-
  read.csv(
    file = "crude_oil_monthly.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

crude_oil <- convert_to_monthly_data(crude_oil_monthly)

names(crude_oil)[1] <- "Time"

names(crude_oil)[2] <- "crude_oil_val"


# View(crude_oil)

remove(crude_oil_monthly)

# Gold
# ICE Benchmark Administration Limited (IBA), Gold Fixing Price 10:30 A.M. (London time) in London Bullion Market, based in U.S. Dollars [GOLDAMGBD228NLBM], retrieved from FRED, Federal Reserve Bank of St. Louis; https://fred.stlouisfed.org/series/GOLDAMGBD228NLBM, November 30, 2019.

gold_daily <-
  read.csv(
    file = "gold_daily_formatted.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE,
    na.strings = c("NA", "NaN", " ", ".", "")
  )

gold_monthly <- convert_to_monthly_data(gold_daily)

names(gold_monthly)[1] <- "Time"

names(gold_monthly)[2] <- "gold_monthly_val"

# # View(gold_monthly)

remove(gold_daily)

# Personal Saving Rate
# U.S. Bureau of Economic Analysis, Personal Saving Rate [PSAVERT], retrieved from FRED, Federal Reserve Bank of St. Louis; https://fred.stlouisfed.org/series/PSAVERT, November 30, 2019.

saving_rate <-
  read.csv(
    file = "personal_saving_rate.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

saving_rate <- convert_to_monthly_data(saving_rate)

names(saving_rate)[1] <- "Time"

names(saving_rate)[2] <- "saving_rate_val"

# # View(saving_rate)

#remove(saving_rate_annual)

# building_permit
# U.S. Census Bureau and U.S. Department of Housing and Urban Development, New Private Housing Units Authorized by Building Permits [PERMIT], retrieved from FRED, Federal Reserve Bank of St. Louis; https://fred.stlouisfed.org/series/PERMIT, November 30, 2019.

building_permit_monthly <-
  read.csv(
    file = "building_permit_monthly.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

building_permit <- convert_to_monthly_data(building_permit_monthly)

names(building_permit)[1] <- "Time"

names(building_permit)[2] <- "building_permit_val"


# # View(building_permit)

remove(building_permit_monthly)

# business_confidence

business_confidence_monthly <-
  read.csv(
    file = "business_confidence_monthly.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

business_confidence <-
  convert_to_monthly_data(business_confidence_monthly)

names(business_confidence)[1] <- "Time"

names(business_confidence)[2] <- "business_confidence_val"

# # View(business_confidence)

remove(business_confidence_monthly)


# consumer_confidence

consumer_confidence_monthly <-
  read.csv(
    file = "consumer_confidence_monthly.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

consumer_confidence <-
  convert_to_monthly_data(consumer_confidence_monthly)

names(consumer_confidence)[1] <- "Time"

names(consumer_confidence)[2] <- "consumer_confidence_val"

# # View(consumer_confidence)

remove(consumer_confidence_monthly)

# Inflation - CPI

cpi_monthly <-
  read.csv(
    file = "cpi_monthly.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

cpi <- convert_to_monthly_data(cpi_monthly)

names(cpi)[1] <- "Time"

names(cpi)[2] <- "cpi_val"

# # View(cpi)

remove(cpi_monthly)

# housing_price

housing_price_quarterly <-
  read.csv(
    file = "housing_price_quarterly.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

housing_price <- convert_to_monthly_data(housing_price_quarterly)

names(housing_price)[1] <- "Time"

names(housing_price)[2] <- "housing_price_val"

# # View(housing_price)

remove(housing_price_quarterly)

# industrial_production

industrial_production_monthly <-
  read.csv(
    file = "industrial_production_monthly.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

industrial_production <-
  convert_to_monthly_data(industrial_production_monthly)

names(industrial_production)[1] <- "Time"

names(industrial_production)[2] <- "industrial_production_val"


# # View(industrial_production)

remove(industrial_production_monthly)

# net_trade

net_trade_monthly <-
  read.csv(
    file = "net_trade_monthly.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

net_trade <- convert_to_monthly_data(net_trade_monthly)

names(net_trade)[1] <- "Time"

names(net_trade)[2] <- "net_trade_val"

# # View(net_trade)

remove(net_trade_monthly)

# production_sales

production_sales_monthly <-
  read.csv(
    file = "production_sales_monthly.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

production_sales <-
  convert_to_monthly_data(production_sales_monthly)

names(production_sales)[1] <- "Time"

names(production_sales)[2] <- "production_val"

names(production_sales)[3] <- "sales_val"


# # View(production_sales)

remove(production_sales_monthly)

# military expense

military_expense <-
  read.csv(
    file = "military_expense.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )


names(military_expense)[1] <- "Time"

names(military_expense)[2] <- "military_expense_val"

military_expense[] <-
  lapply(military_expense, function(x)
    if (is.character(x))
      as.yearmon(x)
    else
      x)

## View(military_expense)


# us_party_in_power

us_party_in_power <-
  read.csv(
    file = "us_party_in_power.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

# View(us_party_in_power)

names(us_party_in_power)[1] <- "Time"

names(us_party_in_power)[2] <- "democrat_rule"

names(us_party_in_power)[3] <- "republican_rule"

## View(us_party_in_power)

us_party_in_power[] <-
  lapply(us_party_in_power, function(x)
    if (is.character(x))
      as.yearmon(x)
    else
      x)


# unemployment rate

unemployment_rate <-
  read.csv(
    file = "unemployment_rate.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

names(unemployment_rate)[1] <- "Time"

names(unemployment_rate)[2] <- "unemployment_rate"

unemployment_rate[] <-
  lapply(unemployment_rate, function(x)
    if (is.character(x))
      as.yearmon(x)
    else
      x)

# View(unemployment_rate)

# us fdi inflow

us_inflow_annual <-
  read.csv(
    file = "us_inflow.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

us_inflow <- convert_to_monthly_data(us_inflow_annual)

names(us_inflow)[1] <- "Time"

names(us_inflow)[2] <- "us_inflow_val"

# View(us_inflow)

remove(us_inflow_annual)

# us fdi outflow

us_outflow_annual <-
  read.csv(
    file = "us_outflow.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

us_outflow <- convert_to_monthly_data(us_outflow_annual)

names(us_outflow)[1] <- "Time"

names(us_outflow)[2] <- "us_outflow_val"

# View(us_outflow)

remove(us_outflow_annual)

# additional_index

additional_index <-
  read.csv(
    file = "additional_index.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

names(additional_index)[1] <- "Time"

additional_index[] <-
  lapply(additional_index, function(x)
    if (is.character(x))
      as.yearmon(x)
    else
      x)

# View(additional_index)

# GDP of major countries

major_countries_gdp_annual <-
  read.csv(
    file = "major_countries_gdp.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

major_countries_gdp <-
  convert_to_monthly_data(major_countries_gdp_annual)

names(major_countries_gdp)[1] <- "Time"

#View(major_countries_gdp)

remove(major_countries_gdp_annual)

# share_price

share_price_monthly <-
  read.csv(
    file = "share_price_monthly.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

share_price <- convert_to_monthly_data(share_price_monthly)

names(share_price)[1] <- "Time"

names(share_price)[2] <- "share_price_val"

# # View(share_price)

remove(share_price_monthly)

# household debt

household_debt_quarter <-
  read.csv(
    file = "household_debt.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

household_debt <- convert_to_monthly_data(household_debt_quarter)

names(household_debt)[1] <- "Time"

names(household_debt)[2] <- "household_debt_val"

# View(household_debt)

remove(household_debt_quarter)

# recession_indicator

recession_indicator <-
  read.csv(
    file = "recession_indicator_monthly.csv",
    header = TRUE,
    sep = "," ,
    stringsAsFactors = FALSE
  )

names(recession_indicator)[1] <- "Time"

names(recession_indicator)[2] <- "recession_indicator_val"

recession_indicator[] <-
  lapply(recession_indicator, function(x)
    if (is.character(x))
      as.yearmon(x)
    else
      x)


# Merging dataframes

masterDfList <-
  list(
    building_permit[1:592,],
    business_confidence[1:592,],
    consumer_confidence[1:592,],
    cpi[1:592,],
    crude_oil[1:592,],
    gdp[1:592,],
    gold_monthly[1:592,],
    housing_price[1:592,],
    income_disposition[1:592,],
    industrial_production[1:592,],
    net_trade[1:592,],
    nonfinancial_business[1:592,],
    production_sales[1:592,],
    saving_rate[1:592,],
    share_price[1:592,],
    military_expense[1:592,],
    us_party_in_power[1:592,],
    unemployment_rate[1:592,],
    us_inflow[1:592,],
    us_outflow[1:592,],
    additional_index[1:592,],
    major_countries_gdp[1:592,],
    household_debt[1:592,],
    recession_indicator[1:592,]
  )

master_data <-
  Reduce(function(x, y)
    merge(x, y, all = TRUE), masterDfList)


#View(master_data)
## Check Master data set for NA's - It is observed that there are NA's in data set
sapply(master_data, function(x)
  sum(is.na(x)))

# # View(master_data)

master_data <-
  master_data[!apply(is.na(master_data) |
                       master_data == "", 1, all),]

# View(master_data)

master_data$Time <- as.Date(as.yearmon(master_data$Time))

# DataExplorer::create_report(master_data)  # GenerateReport(master_data)

#View(psych::describe(master_data))

# View(sapply(master_data, class))

######### Descriptive statistics Using Stargazer package #######################
# stargazer(master_data, type = "html", title="Descriptive statistics", digits = 2, out="DescriptiveStat.html")

##############

## Plot Outliers

#plot_boxplot(master_data[2:53], by = "recession_indicator_val", geom_boxplot_args = list("outlier.color" = "red"))

#capOutlier <- function(x){
#  quantiles <- quantile( x, c(.05, .95 ) )
#  print(quantiles)
#  x[ x < quantiles[1] ] <- quantiles[1]
#  x[ x > quantiles[2] ] <- quantiles[2]
#  return(x)
#}

capOutlier <- function(x) {
  for (i in which(sapply(x, is.numeric))) {
    quantiles <- quantile(x[, i], c(.05, .95), na.rm = TRUE)
    x[, i] = ifelse(x[, i] < quantiles[1] , quantiles[1], x[, i])
    x[, i] = ifelse(x[, i] > quantiles[2] , quantiles[2], x[, i])
  }
  x
}

# dim(master_data)

#plot_boxplot(master_data, by = "recession_indicator_val", geom_boxplot_args = list("outlier.color" = "red"))


master_data = capOutlier(master_data)

# Recession Period Data Timelines

recessions.df = read.table(
  textConnection(
    "Peak, Trough
1969-12-01, 1970-11-01
1973-11-01, 1975-03-01
1980-01-01, 1980-07-01
1981-07-01, 1982-11-01
1990-07-01, 1991-03-01
2001-03-01, 2001-11-01
2007-12-01, 2009-06-01"
  ),
  sep = ',',
  colClasses = c('Date', 'Date'),
  header = TRUE
)

# Forecasting:

forecast_period <- 30


# Created data with transformation with stationary series:

#### ==========================================

# Convert to XTS object

master_data_xts <-
  xts(master_data[,-1], order.by = master_data[, 1])


# We create the complete date vector (with historical and forecast)

dates <-
  seq(
    start(master_data_xts),
    by = "month",
    length.out = nrow(master_data_xts) + forecast_period
  )



last_date_of_historical <- end(master_data_xts)

num_columns <- ncol(master_data) - 1
num_dates    <- nrow(master_data) + forecast_period

recession_plot <- data.frame(matrix(0, num_dates, num_columns))
#View(recession_plot)

row.names(recession_plot) <- dates

#View(recession_plot)

# Auto Arima Custom Function

building_permit_val <-
  auto.arima(master_data$building_permit_val)
pred.building_permit_val <-
  forecast(building_permit_val, h = forecast_period)
building_permit_val_plot <-
  cbind(pred.building_permit_val$fitted,
        pred.building_permit_val$mean)
for (j in 1:num_dates) {
  if (is.na(building_permit_val_plot[j, 1])) {
    recession_plot[j, 1] <-
      building_permit_val_plot[j, 2]
  } else{
    recession_plot[j, 1] <- building_permit_val_plot[j, 1]
  }
}

business_confidence_val <-
  auto.arima(master_data$business_confidence_val)
pred.business_confidence_val <-
  forecast(business_confidence_val, h = forecast_period)
business_confidence_val_plot <-
  cbind(pred.business_confidence_val$fitted,
        pred.business_confidence_val$mean)
for (j in 1:num_dates) {
  if (is.na(business_confidence_val_plot[j, 1])) {
    recession_plot[j, 2] <-
      business_confidence_val_plot[j, 2]
  } else{
    recession_plot[j, 2] <- business_confidence_val_plot[j, 1]
  }
}
#### --------
consumer_confidence_val <-
  auto.arima(master_data$consumer_confidence_val)
pred.consumer_confidence_val <-
  forecast(consumer_confidence_val, h = forecast_period)
consumer_confidence_val_plot <-
  cbind(pred.consumer_confidence_val$fitted,
        pred.consumer_confidence_val$mean)
for (j in 1:num_dates) {
  if (is.na(consumer_confidence_val_plot[j, 1])) {
    recession_plot[j, 3] <-
      consumer_confidence_val_plot[j, 2]
  } else{
    recession_plot[j, 3] <- consumer_confidence_val_plot[j, 1]
  }
}
#### --------
cpi_val <- auto.arima(master_data$cpi_val)
pred.cpi_val <- forecast(cpi_val, h = forecast_period)
cpi_val_plot <- cbind(pred.cpi_val$fitted, pred.cpi_val$mean)
for (j in 1:num_dates) {
  if (is.na(cpi_val_plot[j, 1])) {
    recession_plot[j, 4] <-
      cpi_val_plot[j, 2]
  } else{
    recession_plot[j, 4] <- cpi_val_plot[j, 1]
  }
}
#### --------
crude_oil_val <- auto.arima(master_data$crude_oil_val)
pred.crude_oil_val <- forecast(crude_oil_val, h = forecast_period)
crude_oil_val_plot <-
  cbind(pred.crude_oil_val$fitted, pred.crude_oil_val$mean)
for (j in 1:num_dates) {
  if (is.na(crude_oil_val_plot[j, 1])) {
    recession_plot[j, 5] <-
      crude_oil_val_plot[j, 2]
  } else{
    recession_plot[j, 5] <- crude_oil_val_plot[j, 1]
  }
}
#### --------
gdp_val <- auto.arima(master_data$gdp_val)
pred.gdp_val <- forecast(gdp_val, h = forecast_period)
gdp_val_plot <- cbind(pred.gdp_val$fitted, pred.gdp_val$mean)
for (j in 1:num_dates) {
  if (is.na(gdp_val_plot[j, 1])) {
    recession_plot[j, 6] <-
      gdp_val_plot[j, 2]
  } else{
    recession_plot[j, 6] <- gdp_val_plot[j, 1]
  }
}
#### --------
gold_monthly_val <- auto.arima(master_data$gold_monthly_val)
pred.gold_monthly_val <-
  forecast(gold_monthly_val, h = forecast_period)
gold_monthly_val_plot <-
  cbind(pred.gold_monthly_val$fitted, pred.gold_monthly_val$mean)
for (j in 1:num_dates) {
  if (is.na(gold_monthly_val_plot[j, 1])) {
    recession_plot[j, 7] <-
      gold_monthly_val_plot[j, 2]
  } else{
    recession_plot[j, 7] <- gold_monthly_val_plot[j, 1]
  }
}
#### --------
housing_price_val <- auto.arima(master_data$housing_price_val)
pred.housing_price_val <-
  forecast(housing_price_val, h = forecast_period)
housing_price_val_plot <-
  cbind(pred.housing_price_val$fitted, pred.housing_price_val$mean)
for (j in 1:num_dates) {
  if (is.na(housing_price_val_plot[j, 1])) {
    recession_plot[j, 8] <-
      housing_price_val_plot[j, 2]
  } else{
    recession_plot[j, 8] <- housing_price_val_plot[j, 1]
  }
}
#### --------
income_disposition_val <-
  auto.arima(master_data$income_disposition_val)
pred.income_disposition_val <-
  forecast(income_disposition_val, h = forecast_period)
income_disposition_val_plot <-
  cbind(pred.income_disposition_val$fitted,
        pred.income_disposition_val$mean)
for (j in 1:num_dates) {
  if (is.na(income_disposition_val_plot[j, 1])) {
    recession_plot[j, 9] <-
      income_disposition_val_plot[j, 2]
  } else{
    recession_plot[j, 9] <- income_disposition_val_plot[j, 1]
  }
}
#### --------
industrial_production_val <-
  auto.arima(master_data$industrial_production_val)
pred.industrial_production_val <-
  forecast(industrial_production_val, h = forecast_period)
industrial_production_val_plot <-
  cbind(pred.industrial_production_val$fitted,
        pred.industrial_production_val$mean)
for (j in 1:num_dates) {
  if (is.na(industrial_production_val_plot[j, 1])) {
    recession_plot[j, 10] <-
      industrial_production_val_plot[j, 2]
  } else{
    recession_plot[j, 10] <- industrial_production_val_plot[j, 1]
  }
}
#### --------
net_trade_val <- auto.arima(master_data$net_trade_val)
pred.net_trade_val <- forecast(net_trade_val, h = forecast_period)
net_trade_val_plot <-
  cbind(pred.net_trade_val$fitted, pred.net_trade_val$mean)
for (j in 1:num_dates) {
  if (is.na(net_trade_val_plot[j, 1])) {
    recession_plot[j, 11] <-
      net_trade_val_plot[j, 2]
  } else{
    recession_plot[j, 11] <- net_trade_val_plot[j, 1]
  }
}
#### --------
nonfinancial_business_val <-
  auto.arima(master_data$nonfinancial_business_val)
pred.nonfinancial_business_val <-
  forecast(nonfinancial_business_val, h = forecast_period)
nonfinancial_business_val_plot <-
  cbind(pred.nonfinancial_business_val$fitted,
        pred.nonfinancial_business_val$mean)
for (j in 1:num_dates) {
  if (is.na(nonfinancial_business_val_plot[j, 1])) {
    recession_plot[j, 12] <-
      nonfinancial_business_val_plot[j, 2]
  } else{
    recession_plot[j, 12] <- nonfinancial_business_val_plot[j, 1]
  }
}
#### --------
production_val <- auto.arima(master_data$production_val)
pred.production_val <- forecast(production_val, h = forecast_period)
production_val_plot <-
  cbind(pred.production_val$fitted, pred.production_val$mean)
for (j in 1:num_dates) {
  if (is.na(production_val_plot[j, 1])) {
    recession_plot[j, 13] <-
      production_val_plot[j, 2]
  } else{
    recession_plot[j, 13] <- production_val_plot[j, 1]
  }
}
#### --------
sales_val <- auto.arima(master_data$sales_val)
pred.sales_val <- forecast(sales_val, h = forecast_period)
sales_val_plot <- cbind(pred.sales_val$fitted, pred.sales_val$mean)
for (j in 1:num_dates) {
  if (is.na(sales_val_plot[j, 1])) {
    recession_plot[j, 14] <-
      sales_val_plot[j, 2]
  } else{
    recession_plot[j, 14] <- sales_val_plot[j, 1]
  }
}
#### --------
saving_rate_val <- auto.arima(master_data$saving_rate_val)
pred.saving_rate_val <-
  forecast(saving_rate_val, h = forecast_period)
saving_rate_val_plot <-
  cbind(pred.saving_rate_val$fitted, pred.saving_rate_val$mean)
for (j in 1:num_dates) {
  if (is.na(saving_rate_val_plot[j, 1])) {
    recession_plot[j, 15] <-
      saving_rate_val_plot[j, 2]
  } else{
    recession_plot[j, 15] <- saving_rate_val_plot[j, 1]
  }
}
#### --------
share_price_val <- auto.arima(master_data$share_price_val)
pred.share_price_val <-
  forecast(share_price_val, h = forecast_period)
share_price_val_plot <-
  cbind(pred.share_price_val$fitted, pred.share_price_val$mean)
for (j in 1:num_dates) {
  if (is.na(share_price_val_plot[j, 1])) {
    recession_plot[j, 16] <-
      share_price_val_plot[j, 2]
  } else{
    recession_plot[j, 16] <- share_price_val_plot[j, 1]
  }
}
#### --------
military_expense_val <-
  auto.arima(master_data$military_expense_val)
pred.military_expense_val <-
  forecast(military_expense_val, h = forecast_period)
military_expense_val_plot <-
  cbind(pred.military_expense_val$fitted,
        pred.military_expense_val$mean)
for (j in 1:num_dates) {
  if (is.na(military_expense_val_plot[j, 1])) {
    recession_plot[j, 17] <-
      military_expense_val_plot[j, 2]
  } else{
    recession_plot[j, 17] <- military_expense_val_plot[j, 1]
  }
}
#### --------
democrat_rule <- auto.arima(master_data$democrat_rule)
pred.democrat_rule <- forecast(democrat_rule, h = forecast_period)
democrat_rule_plot <-
  cbind(pred.democrat_rule$fitted, pred.democrat_rule$mean)
for (j in 1:num_dates) {
  if (is.na(democrat_rule_plot[j, 1])) {
    recession_plot[j, 18] <-
      democrat_rule_plot[j, 2]
  } else{
    recession_plot[j, 18] <- democrat_rule_plot[j, 1]
  }
}
#### --------
republican_rule <- auto.arima(master_data$republican_rule)
pred.republican_rule <-
  forecast(republican_rule, h = forecast_period)
republican_rule_plot <-
  cbind(pred.republican_rule$fitted, pred.republican_rule$mean)
for (j in 1:num_dates) {
  if (is.na(republican_rule_plot[j, 1])) {
    recession_plot[j, 19] <-
      republican_rule_plot[j, 2]
  } else{
    recession_plot[j, 19] <- republican_rule_plot[j, 1]
  }
}
#### --------
unemployment_rate <- auto.arima(master_data$unemployment_rate)
pred.unemployment_rate <-
  forecast(unemployment_rate, h = forecast_period)
unemployment_rate_plot <-
  cbind(pred.unemployment_rate$fitted, pred.unemployment_rate$mean)
for (j in 1:num_dates) {
  if (is.na(unemployment_rate_plot[j, 1])) {
    recession_plot[j, 20] <-
      unemployment_rate_plot[j, 2]
  } else{
    recession_plot[j, 20] <- unemployment_rate_plot[j, 1]
  }
}
#### --------
us_inflow_val <- auto.arima(master_data$us_inflow_val)
pred.us_inflow_val <- forecast(us_inflow_val, h = forecast_period)
us_inflow_val_plot <-
  cbind(pred.us_inflow_val$fitted, pred.us_inflow_val$mean)
for (j in 1:num_dates) {
  if (is.na(us_inflow_val_plot[j, 1])) {
    recession_plot[j, 21] <-
      us_inflow_val_plot[j, 2]
  } else{
    recession_plot[j, 21] <- us_inflow_val_plot[j, 1]
  }
}
#### --------
us_outflow_val <- auto.arima(master_data$us_outflow_val)
pred.us_outflow_val <- forecast(us_outflow_val, h = forecast_period)
us_outflow_val_plot <-
  cbind(pred.us_outflow_val$fitted, pred.us_outflow_val$mean)
for (j in 1:num_dates) {
  if (is.na(us_outflow_val_plot[j, 1])) {
    recession_plot[j, 22] <-
      us_outflow_val_plot[j, 2]
  } else{
    recession_plot[j, 22] <- us_outflow_val_plot[j, 1]
  }
}
#### --------
help_wanted_idx <- auto.arima(master_data$help_wanted_idx)
pred.help_wanted_idx <-
  forecast(help_wanted_idx, h = forecast_period)
help_wanted_idx_plot <-
  cbind(pred.help_wanted_idx$fitted, pred.help_wanted_idx$mean)
for (j in 1:num_dates) {
  if (is.na(help_wanted_idx_plot[j, 1])) {
    recession_plot[j, 23] <-
      help_wanted_idx_plot[j, 2]
  } else{
    recession_plot[j, 23] <- help_wanted_idx_plot[j, 1]
  }
}
#### --------
avg_employment_duration_week <-
  auto.arima(master_data$avg_employment_duration_week)
pred.avg_employment_duration_week <-
  forecast(avg_employment_duration_week, h = forecast_period)
avg_employment_duration_week_plot <-
  cbind(
    pred.avg_employment_duration_week$fitted,
    pred.avg_employment_duration_week$mean
  )
for (j in 1:num_dates) {
  if (is.na(avg_employment_duration_week_plot[j, 1])) {
    recession_plot[j, 24] <-
      avg_employment_duration_week_plot[j, 2]
  } else{
    recession_plot[j, 24] <- avg_employment_duration_week_plot[j, 1]
  }
}
#### --------
employment_insurance_claim <-
  auto.arima(master_data$employment_insurance_claim)
pred.employment_insurance_claim <-
  forecast(employment_insurance_claim, h = forecast_period)
employment_insurance_claim_plot <-
  cbind(pred.employment_insurance_claim$fitted,
        pred.employment_insurance_claim$mean)
for (j in 1:num_dates) {
  if (is.na(employment_insurance_claim_plot[j, 1])) {
    recession_plot[j, 25] <-
      employment_insurance_claim_plot[j, 2]
  } else{
    recession_plot[j, 25] <- employment_insurance_claim_plot[j, 1]
  }
}
#### --------
eff_fed_fund_rate <- auto.arima(master_data$eff_fed_fund_rate)
pred.eff_fed_fund_rate <-
  forecast(eff_fed_fund_rate, h = forecast_period)
eff_fed_fund_rate_plot <-
  cbind(pred.eff_fed_fund_rate$fitted, pred.eff_fed_fund_rate$mean)
for (j in 1:num_dates) {
  if (is.na(eff_fed_fund_rate_plot[j, 1])) {
    recession_plot[j, 26] <-
      eff_fed_fund_rate_plot[j, 2]
  } else{
    recession_plot[j, 26] <- eff_fed_fund_rate_plot[j, 1]
  }
}
#### --------
xchg_switz_us_curr <-
  auto.arima(master_data$xchg_switz_us_curr)
pred.xchg_switz_us_curr <-
  forecast(xchg_switz_us_curr, h = forecast_period)
xchg_switz_us_curr_plot <-
  cbind(pred.xchg_switz_us_curr$fitted,
        pred.xchg_switz_us_curr$mean)
for (j in 1:num_dates) {
  if (is.na(xchg_switz_us_curr_plot[j, 1])) {
    recession_plot[j, 27] <-
      xchg_switz_us_curr_plot[j, 2]
  } else{
    recession_plot[j, 27] <- xchg_switz_us_curr_plot[j, 1]
  }
}
#### --------
xchg_jpn_us_curr <- auto.arima(master_data$xchg_jpn_us_curr)
pred.xchg_jpn_us_curr <-
  forecast(xchg_jpn_us_curr, h = forecast_period)
xchg_jpn_us_curr_plot <-
  cbind(pred.xchg_jpn_us_curr$fitted, pred.xchg_jpn_us_curr$mean)
for (j in 1:num_dates) {
  if (is.na(xchg_jpn_us_curr_plot[j, 1])) {
    recession_plot[j, 28] <-
      xchg_jpn_us_curr_plot[j, 2]
  } else{
    recession_plot[j, 28] <- xchg_jpn_us_curr_plot[j, 1]
  }
}
#### --------
xchg_uk_us_curr <- auto.arima(master_data$xchg_uk_us_curr)
pred.xchg_uk_us_curr <-
  forecast(xchg_uk_us_curr, h = forecast_period)
xchg_uk_us_curr_plot <-
  cbind(pred.xchg_uk_us_curr$fitted, pred.xchg_uk_us_curr$mean)
for (j in 1:num_dates) {
  if (is.na(xchg_uk_us_curr_plot[j, 1])) {
    recession_plot[j, 29] <-
      xchg_uk_us_curr_plot[j, 2]
  } else{
    recession_plot[j, 29] <- xchg_uk_us_curr_plot[j, 1]
  }
}
#### --------
xchg_cad_us_curr <- auto.arima(master_data$xchg_cad_us_curr)
pred.xchg_cad_us_curr <-
  forecast(xchg_cad_us_curr, h = forecast_period)
xchg_cad_us_curr_plot <-
  cbind(pred.xchg_cad_us_curr$fitted, pred.xchg_cad_us_curr$mean)
for (j in 1:num_dates) {
  if (is.na(xchg_cad_us_curr_plot[j, 1])) {
    recession_plot[j, 30] <-
      xchg_cad_us_curr_plot[j, 2]
  } else{
    recession_plot[j, 30] <- xchg_cad_us_curr_plot[j, 1]
  }
}
#### --------
germany_recession <- auto.arima(master_data$germany_recession)
pred.germany_recession <-
  forecast(germany_recession, h = forecast_period)
germany_recession_plot <-
  cbind(pred.germany_recession$fitted, pred.germany_recession$mean)
for (j in 1:num_dates) {
  if (is.na(germany_recession_plot[j, 1])) {
    recession_plot[j, 31] <-
      germany_recession_plot[j, 2]
  } else{
    recession_plot[j, 31] <- germany_recession_plot[j, 1]
  }
}
#### --------
italy_recession <- auto.arima(master_data$italy_recession)
pred.italy_recession <-
  forecast(italy_recession, h = forecast_period)
italy_recession_plot <-
  cbind(pred.italy_recession$fitted, pred.italy_recession$mean)
for (j in 1:num_dates) {
  if (is.na(italy_recession_plot[j, 1])) {
    recession_plot[j, 32] <-
      italy_recession_plot[j, 2]
  } else{
    recession_plot[j, 32] <- italy_recession_plot[j, 1]
  }
}
#### --------
france_recession <- auto.arima(master_data$france_recession)
pred.france_recession <-
  forecast(france_recession, h = forecast_period)
france_recession_plot <-
  cbind(pred.france_recession$fitted, pred.france_recession$mean)
for (j in 1:num_dates) {
  if (is.na(france_recession_plot[j, 1])) {
    recession_plot[j, 33] <-
      france_recession_plot[j, 2]
  } else{
    recession_plot[j, 33] <- france_recession_plot[j, 1]
  }
}
#### --------
canada_recession <- auto.arima(master_data$canada_recession)
pred.canada_recession <-
  forecast(canada_recession, h = forecast_period)
canada_recession_plot <-
  cbind(pred.canada_recession$fitted, pred.canada_recession$mean)
for (j in 1:num_dates) {
  if (is.na(canada_recession_plot[j, 1])) {
    recession_plot[j, 34] <-
      canada_recession_plot[j, 2]
  } else{
    recession_plot[j, 34] <- canada_recession_plot[j, 1]
  }
}
#### --------
japan_recession <- auto.arima(master_data$japan_recession)
pred.japan_recession <-
  forecast(japan_recession, h = forecast_period)
japan_recession_plot <-
  cbind(pred.japan_recession$fitted, pred.japan_recession$mean)
for (j in 1:num_dates) {
  if (is.na(japan_recession_plot[j, 1])) {
    recession_plot[j, 35] <-
      japan_recession_plot[j, 2]
  } else{
    recession_plot[j, 35] <- japan_recession_plot[j, 1]
  }
}
#### --------
uk_recession <- auto.arima(master_data$uk_recession)
pred.uk_recession <- forecast(uk_recession, h = forecast_period)
uk_recession_plot <-
  cbind(pred.uk_recession$fitted, pred.uk_recession$mean)
for (j in 1:num_dates) {
  if (is.na(uk_recession_plot[j, 1])) {
    recession_plot[j, 36] <-
      uk_recession_plot[j, 2]
  } else{
    recession_plot[j, 36] <- uk_recession_plot[j, 1]
  }
}
#### --------
s_and_p_return_rate <-
  auto.arima(master_data$s_and_p_return_rate)
pred.s_and_p_return_rate <-
  forecast(s_and_p_return_rate, h = forecast_period)
s_and_p_return_rate_plot <-
  cbind(pred.s_and_p_return_rate$fitted,
        pred.s_and_p_return_rate$mean)
for (j in 1:num_dates) {
  if (is.na(s_and_p_return_rate_plot[j, 1])) {
    recession_plot[j, 37] <-
      s_and_p_return_rate_plot[j, 2]
  } else{
    recession_plot[j, 37] <- s_and_p_return_rate_plot[j, 1]
  }
}
#### --------
long_term_yield_rate_us <-
  auto.arima(master_data$long_term_yield_rate_us)
pred.long_term_yield_rate_us <-
  forecast(long_term_yield_rate_us, h = forecast_period)
long_term_yield_rate_us_plot <-
  cbind(pred.long_term_yield_rate_us$fitted,
        pred.long_term_yield_rate_us$mean)
for (j in 1:num_dates) {
  if (is.na(long_term_yield_rate_us_plot[j, 1])) {
    recession_plot[j, 38] <-
      long_term_yield_rate_us_plot[j, 2]
  } else{
    recession_plot[j, 38] <- long_term_yield_rate_us_plot[j, 1]
  }
}
#### --------
long_term_yield_rate_germany <-
  auto.arima(master_data$long_term_yield_rate_germany)
pred.long_term_yield_rate_germany <-
  forecast(long_term_yield_rate_germany, h = forecast_period)
long_term_yield_rate_germany_plot <-
  cbind(
    pred.long_term_yield_rate_germany$fitted,
    pred.long_term_yield_rate_germany$mean
  )
for (j in 1:num_dates) {
  if (is.na(long_term_yield_rate_germany_plot[j, 1])) {
    recession_plot[j, 39] <-
      long_term_yield_rate_germany_plot[j, 2]
  } else{
    recession_plot[j, 39] <- long_term_yield_rate_germany_plot[j, 1]
  }
}
#### --------
long_term_yield_rate_canada <-
  auto.arima(master_data$long_term_yield_rate_canada)
pred.long_term_yield_rate_canada <-
  forecast(long_term_yield_rate_canada, h = forecast_period)
long_term_yield_rate_canada_plot <-
  cbind(pred.long_term_yield_rate_canada$fitted,
        pred.long_term_yield_rate_canada$mean)
for (j in 1:num_dates) {
  if (is.na(long_term_yield_rate_canada_plot[j, 1])) {
    recession_plot[j, 40] <-
      long_term_yield_rate_canada_plot[j, 2]
  } else{
    recession_plot[j, 40] <- long_term_yield_rate_canada_plot[j, 1]
  }
}
#### --------
long_term_yield_rate_france <-
  auto.arima(master_data$long_term_yield_rate_france)
pred.long_term_yield_rate_france <-
  forecast(long_term_yield_rate_france, h = forecast_period)
long_term_yield_rate_france_plot <-
  cbind(pred.long_term_yield_rate_france$fitted,
        pred.long_term_yield_rate_france$mean)
for (j in 1:num_dates) {
  if (is.na(long_term_yield_rate_france_plot[j, 1])) {
    recession_plot[j, 41] <-
      long_term_yield_rate_france_plot[j, 2]
  } else{
    recession_plot[j, 41] <- long_term_yield_rate_france_plot[j, 1]
  }
}
#### --------
long_term_yield_rate_uk <-
  auto.arima(master_data$long_term_yield_rate_uk)
pred.long_term_yield_rate_uk <-
  forecast(long_term_yield_rate_uk, h = forecast_period)
long_term_yield_rate_uk_plot <-
  cbind(pred.long_term_yield_rate_uk$fitted,
        pred.long_term_yield_rate_uk$mean)
for (j in 1:num_dates) {
  if (is.na(long_term_yield_rate_uk_plot[j, 1])) {
    recession_plot[j, 42] <-
      long_term_yield_rate_uk_plot[j, 2]
  } else{
    recession_plot[j, 42] <- long_term_yield_rate_uk_plot[j, 1]
  }
}
#### --------
japan_gdp <- auto.arima(master_data$japan_gdp)
pred.japan_gdp <- forecast(japan_gdp, h = forecast_period)
japan_gdp_plot <-
  cbind(pred.japan_gdp$fitted, pred.japan_gdp$mean)
for (j in 1:num_dates) {
  if (is.na(japan_gdp_plot[j, 1])) {
    recession_plot[j, 43] <-
      japan_gdp_plot[j, 2]
  } else{
    recession_plot[j, 43] <- japan_gdp_plot[j, 1]
  }
}
#### --------
canada_gdp <- auto.arima(master_data$canada_gdp)
pred.canada_gdp <- forecast(canada_gdp, h = forecast_period)
canada_gdp_plot <-
  cbind(pred.canada_gdp$fitted, pred.canada_gdp$mean)
for (j in 1:num_dates) {
  if (is.na(canada_gdp_plot[j, 1])) {
    recession_plot[j, 44] <-
      canada_gdp_plot[j, 2]
  } else{
    recession_plot[j, 44] <- canada_gdp_plot[j, 1]
  }
}
#### --------
france_gdp <- auto.arima(master_data$france_gdp)
pred.france_gdp <- forecast(france_gdp, h = forecast_period)
france_gdp_plot <-
  cbind(pred.france_gdp$fitted, pred.france_gdp$mean)
for (j in 1:num_dates) {
  if (is.na(france_gdp_plot[j, 1])) {
    recession_plot[j, 45] <-
      france_gdp_plot[j, 2]
  } else{
    recession_plot[j, 45] <- france_gdp_plot[j, 1]
  }
}
#### --------
germany_gdp <- auto.arima(master_data$germany_gdp)
pred.germany_gdp <- forecast(germany_gdp, h = forecast_period)
germany_gdp_plot <-
  cbind(pred.germany_gdp$fitted, pred.germany_gdp$mean)
for (j in 1:num_dates) {
  if (is.na(germany_gdp_plot[j, 1])) {
    recession_plot[j, 46] <-
      germany_gdp_plot[j, 2]
  } else{
    recession_plot[j, 46] <- germany_gdp_plot[j, 1]
  }
}
#### --------
italy_gdp <- auto.arima(master_data$italy_gdp)
pred.italy_gdp <- forecast(italy_gdp, h = forecast_period)
italy_gdp_plot <- cbind(pred.italy_gdp$fitted, pred.italy_gdp$mean)
for (j in 1:num_dates) {
  if (is.na(italy_gdp_plot[j, 1])) {
    recession_plot[j, 47] <-
      italy_gdp_plot[j, 2]
  } else{
    recession_plot[j, 47] <- italy_gdp_plot[j, 1]
  }
}
#### --------
uk_gdp <- auto.arima(master_data$uk_gdp)
pred.uk_gdp <- forecast(uk_gdp, h = forecast_period)
uk_gdp_plot <- cbind(pred.uk_gdp$fitted, pred.uk_gdp$mean)
for (j in 1:num_dates) {
  if (is.na(uk_gdp_plot[j, 1])) {
    recession_plot[j, 48] <-
      uk_gdp_plot[j, 2]
  } else{
    recession_plot[j, 48] <- uk_gdp_plot[j, 1]
  }
}
#### --------
china_gdp <- auto.arima(master_data$china_gdp)
pred.china_gdp <- forecast(china_gdp, h = forecast_period)
china_gdp_plot <- cbind(pred.china_gdp$fitted, pred.china_gdp$mean)
for (j in 1:num_dates) {
  if (is.na(china_gdp_plot[j, 1])) {
    recession_plot[j, 49] <-
      china_gdp_plot[j, 2]
  } else{
    recession_plot[j, 49] <- china_gdp_plot[j, 1]
  }
}
#### --------
india_gdp <- auto.arima(master_data$india_gdp)
pred.india_gdp <- forecast(india_gdp, h = forecast_period)
india_gdp_plot <- cbind(pred.india_gdp$fitted, pred.india_gdp$mean)
for (j in 1:num_dates) {
  if (is.na(india_gdp_plot[j, 1])) {
    recession_plot[j, 50] <-
      india_gdp_plot[j, 2]
  } else{
    recession_plot[j, 50] <- india_gdp_plot[j, 1]
  }
}
#### --------
household_debt_val <-
  auto.arima(master_data$household_debt_val)
pred.household_debt_val <-
  forecast(household_debt_val, h = forecast_period)
household_debt_val_plot <-
  cbind(pred.household_debt_val$fitted,
        pred.household_debt_val$mean)
for (j in 1:num_dates) {
  if (is.na(household_debt_val_plot[j, 1])) {
    recession_plot[j, 51] <-
      household_debt_val_plot[j, 2]
  } else{
    recession_plot[j, 51] <- household_debt_val_plot[j, 1]
  }
}

library( BBmisc)





# ------------------- On Training Data

# View(master_data)

remove(Training.Set)
remove(In.Sample.Test.Set)

set.seed(54321)

#View(Training.Set)
# Creamos la BBDD con la data a analizar y a entrenar el modelo
Training.Set <- master_data[1:432,-c(1)]

In.Sample.Test.Set <- master_data[433:592, -c(1)]

Training.Set[,-ncol(Training.Set)] <- normalize(Training.Set[,-ncol(Training.Set)], method = "standardize", range = c(0, 1), margin = 1L, on.constant = "quiet")

In.Sample.Test.Set[,-ncol(In.Sample.Test.Set)] <- normalize(In.Sample.Test.Set[,-ncol(In.Sample.Test.Set)], method = "standardize", range = c(0, 1), margin = 1L, on.constant = "quiet")

classifier_bayesglm_base <- bayesglm(formula = recession_indicator_val ~ .,
                                family = binomial(link = "logit"), maxit = 110, 
                                data = Training.Set)



library(stats)

prob <- classifier_bayesglm_base[["fitted.values"]] # Valores obtenidos del modelo

optCutOff <- optimalCutoff(Training.Set$recession_indicator_val, prob)[1] 

optCutOff

summary(classifier_bayesglm_base)

# View(vif(classifier_bayesglm_base))

misClassError(Training.Set$recession_indicator_val, prob, threshold = optCutOff)

plotROC(Training.Set$recession_indicator_val, prob)

Concordance(Training.Set$recession_indicator_val, prob)

sensitivity(Training.Set$recession_indicator_val, prob, threshold = optCutOff)

specificity(Training.Set$recession_indicator_val, prob, threshold = optCutOff)

confusionMatrix(Training.Set$recession_indicator_val, prob, threshold = optCutOff)

predTrain <- factor(ifelse(prob >= optCutOff, 1, 0))
actualPred <- factor(Training.Set$recession_indicator_val)

# Checking classification accuracy
cf <- caret::confusionMatrix(predTrain, actualPred, positive='1')

cf$byClass


cf

# In Sample Test Data Prediction 

in_sample_prob_pred = predict(classifier_bayesglm_base, type = 'response', newdata = In.Sample.Test.Set)

predTest <- factor(ifelse(in_sample_prob_pred >= optCutOff, 1, 0))
actualPredTest <- factor(In.Sample.Test.Set$recession_indicator_val)

# Checking classification accuracy
cf1 <- caret::confusionMatrix(predTest, actualPredTest, positive='1')

cf1$byClass

plotROC(In.Sample.Test.Set$recession_indicator_val, in_sample_prob_pred)

cf1

# Now create model with full data
#========================================

## --------------------- Now use complete master_data for model creation

#install.packages("microbenchmark", dependencies = TRUE)
#library("microbenchmark")




set.seed(100)

remove(Final.Training.Set)
remove(Test.Set)


# Creamos la BBDD con la data a analizar y a entrenar el modelo
Final.Training.Set <- master_data[,-c(1)]

row.names(Final.Training.Set) <- NULL

colnames(Final.Training.Set)  <- colnames(master_data[,-c(1)])

#rescale(Final.Training.Set$recession_indicator_val,"center")

dim(Final.Training.Set)

Final.Training.Set[,-ncol(Final.Training.Set)] <- normalize(Final.Training.Set[,-ncol(Final.Training.Set)], method = "standardize", range = c(0, 1), margin = 1L, on.constant = "quiet")

sapply(Final.Training.Set, function(x)
  sum(is.na(x)))

classifier_bayesglm <- bayesglm(formula = recession_indicator_val ~ .,
                                family = binomial(link = "logit"), maxit = 110, 
                                data = Final.Training.Set)

prob <- classifier_bayesglm_base[["fitted.values"]] 

prob1 = predict(classifier_bayesglm_base, 
                    type = 'response', 
                    newdata = Final.Training.Set) # Prediction


remove(Test.Set)
# We created the testset to perform the forecast
Test.Set <- data.frame(pred.building_permit_val$mean,pred.business_confidence_val$mean,pred.consumer_confidence_val$mean,pred.cpi_val$mean,pred.crude_oil_val$mean,pred.gdp_val$mean,pred.gold_monthly_val$mean,pred.housing_price_val$mean,pred.income_disposition_val$mean,pred.industrial_production_val$mean,pred.net_trade_val$mean,pred.nonfinancial_business_val$mean,pred.production_val$mean,pred.sales_val$mean,pred.saving_rate_val$mean,pred.share_price_val$mean,pred.military_expense_val$mean,pred.democrat_rule$mean,pred.republican_rule$mean,pred.unemployment_rate$mean,pred.us_inflow_val$mean,pred.us_outflow_val$mean,pred.help_wanted_idx$mean,pred.avg_employment_duration_week$mean,pred.employment_insurance_claim$mean,pred.eff_fed_fund_rate$mean,pred.xchg_switz_us_curr$mean,pred.xchg_jpn_us_curr$mean,pred.xchg_uk_us_curr$mean,pred.xchg_cad_us_curr$mean,pred.germany_recession$mean,pred.italy_recession$mean,pred.france_recession$mean,pred.canada_recession$mean,pred.japan_recession$mean,pred.uk_recession$mean,pred.s_and_p_return_rate$mean,pred.long_term_yield_rate_us$mean,pred.long_term_yield_rate_germany$mean,pred.long_term_yield_rate_canada$mean,pred.long_term_yield_rate_france$mean,pred.long_term_yield_rate_uk$mean,pred.japan_gdp$mean,pred.canada_gdp$mean,pred.france_gdp$mean,pred.germany_gdp$mean,pred.italy_gdp$mean,pred.uk_gdp$mean,pred.china_gdp$mean,pred.india_gdp$mean,pred.household_debt_val$mean)

sapply(Test.Set, function(x)
  sum(is.na(x)))

colnames(Test.Set) <- c("building_permit_val","business_confidence_val","consumer_confidence_val","cpi_val","crude_oil_val","gdp_val","gold_monthly_val","housing_price_val","income_disposition_val","industrial_production_val","net_trade_val","nonfinancial_business_val","production_val","sales_val","saving_rate_val","share_price_val","military_expense_val","democrat_rule","republican_rule","unemployment_rate","us_inflow_val","us_outflow_val","help_wanted_idx","avg_employment_duration_week","employment_insurance_claim","eff_fed_fund_rate","xchg_switz_us_curr","xchg_jpn_us_curr","xchg_uk_us_curr","xchg_cad_us_curr","germany_recession","italy_recession","france_recession","canada_recession","japan_recession","uk_recession","s_and_p_return_rate","long_term_yield_rate_us","long_term_yield_rate_germany","long_term_yield_rate_canada","long_term_yield_rate_france","long_term_yield_rate_uk","japan_gdp","canada_gdp","france_gdp","germany_gdp","italy_gdp","uk_gdp","china_gdp","india_gdp","household_debt_val")

dim(Test.Set)

Test.Set <- normalize(Test.Set, method = "standardize", range = c(0, 1), margin = 1L, on.constant = "quiet")


sapply(Test.Set, function(x)
  sum(is.na(x)))

plot(classifier_bayesglm_base$residuals)


remove(prob_pred)

prob_pred = predict(classifier_bayesglm_base, 
                    type = 'response', 
                    newdata = Test.Set) # Predicci�n

library(InformationValue)

optCutOff <- optimalCutoff(Final.Training.Set$recession_indicator_val, prob1)[1] 

optCutOff

summary(classifier_bayesglm)

vif(classifier_bayesglm)

misClassError(Final.Training.Set$recession_indicator_val, prob1, threshold = optCutOff)

plotROC(Final.Training.Set$recession_indicator_val, prob1)

Concordance(Final.Training.Set$recession_indicator_val, prob1)

sensitivity(Final.Training.Set$recession_indicator_val, prob1, threshold = optCutOff)

specificity(Final.Training.Set$recession_indicator_val, prob1, threshold = optCutOff)

confusionMatrix(Final.Training.Set$recession_indicator_val, prob1, threshold = optCutOff)

predTrain <- factor(ifelse(prob1 >= optCutOff, 1, 0))
actualPred <- factor(Final.Training.Set$recession_indicator_val)

# Checking classification accuracy
cf <- caret::confusionMatrix(predTrain, actualPred,positive='1')

cf$byClass


Final.Test.Recession <- factor(ifelse(prob_pred >= optCutOff, 1, 0))

total_probability <- c(prob1 ,prob_pred)

remove(recession_prob)

recession_prob <- data.frame(dates, total_probability)
colnames(recession_prob) <- c("Dates", "Probability")

# Let's create the color code
recession_prob$col <- 0
for(i in 1:nrow(recession_prob)){
  if(recession_prob$Probability[i] < 0.20){
    recession_prob$col[i] <- "green" 
  }else if(recession_prob$Probability[i] > 0.20 & recession_prob$Probability[i] < optCutOff){
    recession_prob$col[i] <- "orange" 
  }else if(recession_prob$Probability[i] > optCutOff & recession_prob$Probability[i] < 1.00){
    recession_prob$col[i] <- "red" 
  }
}

# We graph the results of the Prediction
# We look for the maximum future value

row.projection <- nrow(recession_prob) - forecast_period
final.row <- nrow(recession_prob)

maximum_probability <- max(recession_prob[row.projection:final.row,2])

date.Recession <- recession_prob[recession_prob$Probability == maximum_probability, 1]

# We adjust the length of the database to be able to graph
recession_prob <- recession_prob[1:(nrow(master_data) + forecast_period), ]

recession_ggplot <- ggplot(data = recession_prob, aes(x = dates, y = Probability)) + 
  geom_line(aes(colour = col, group = 1), size = 0.9) +
  scale_colour_identity() + 
  geom_rect(data = recessions.df, inherit.aes = FALSE,
            aes(xmin = Peak, xmax = Trough, ymin = -Inf, ymax = +Inf), 
            fill = 'lightblue', alpha = 0.4) +
  theme_minimal() +
  labs(x = "", y = "", title = "Probability of a Recession in the United States",
       subtitle = paste("The probability of a recession during the next ", forecast_period, " month(s) is close to ", round(maximum_probability*100, digits = 3), " - Start date of the recession: ", date.Recession, sep = ""),
       caption = "Created by: Abhishek Pratik (@apratik).") +
  geom_hline(yintercept = 0,color = "blue") +
  theme(plot.caption = element_text(hjust = 0),
        plot.subtitle = element_text(face = "italic",size = 9),
        plot.title = element_text(face = "bold", size = 14)) + theme(legend.position = "none") + 
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) + scale_y_continuous(labels = scales::percent) + scale_x_date(date_breaks = '1 years', labels = date_format("%b-%y"))

recession_ggplot